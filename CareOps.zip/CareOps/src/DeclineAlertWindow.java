import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Decline Alert Window class with all JSwing components
public class DeclineAlertWindow
{

    private JPanel declinePanel;
    private JButton closeButton;
    private JLabel warningLabel;
    private JLabel residentNameLabel;
    private JLabel eContactTitleLabel;
    private JLabel residentEcontactLabel;
    private JLabel noteLabel;

    //Declare JFrame
    JFrame alertWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public DeclineAlertWindow()
    {

        //Action Listener for the Close Window Button
        closeButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                alertWindowFrame.dispose();
            }
        });

        //METHOD TO CHANGE RESIDENT LABEL TO RESIDENT NAME (USES SQL)
        //METHOD TO CHANGE RESIDENT E CONTACT LABEL TO E CONTACT (USES SQL)

    }

    //Method for creating an object to attach form to
    public static void openDeclineAlertWindow()
    {
        DeclineAlertWindow declineObj = new DeclineAlertWindow();
        declineObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        alertWindowFrame.setContentPane(new DeclineAlertWindow().declinePanel);
        alertWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        alertWindowFrame.setTitle("HEALTH DECLINE DETECTED!");
        alertWindowFrame.setSize(250, 200);
        alertWindowFrame.setLocationRelativeTo(null);
        alertWindowFrame.setVisible(true);

    }

}
