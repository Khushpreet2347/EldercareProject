public class TrendAnalyzer
{

    //Method to grab last 14 days of records
    public static void getRecordsTwoWeeks(int residentIDInput)
    {

        /*
        SELECT *
        FROM HealthRecords
        WHERE residentID = residentIDInput
        ORDER BY date DESC
        LIMIT 14
         */

        //CONVERT TO OBJECT

    }

    public static void declineDetectionAlgorithm()
    {

        //Variables
        int recordID;
        int residentID;
        //date recordDate;

        String weekOneRecords;
        String weekTwoRecords;
        int weekOneFlags = 0;
        int weekTwoFlags = 0;

        int firstSystolicPressure = 0;
        int firstDiastolicPressure = 0;
        int firstBloodSugar = 0;
        int firstHeartRate = 0;
        double firstBodyTemp = 0.0;

        int secondSystolicPressure = 0;
        int secondDiastolicPressure = 0;
        int secondBloodSugar = 0;
        int secondHeartRate = 0;
        double secondBodyTemp = 0.0;

        //Create a list of health record objects

        //List<HealthRecord> records = getRecordsTwoWeeks(residentID);

        //Check if there are 14 records

        //if(records.size() < 14)
        //{

        //}

        //Spilt list into the first and second weeks using sublist method
        /*
        List<HealthRecord> weekOneRecords = records.subList(0, 7);
        List<HealthRecord> weekTwoRecords = records.subList(7, 14);
         */

        //COUNT FLAGS FOR WEEK ONE////////////////////////////////////////

        //Count flags for unusual Blood Pressure
        if(firstSystolicPressure < 90 || firstSystolicPressure > 130)
        {
            //CHECK SUBLIST FOR VALUES, FOR LOOP, LOOP THROUGH EACH RECORD IN LIST
            weekOneFlags++;
        }

        if(firstDiastolicPressure < 60 || firstDiastolicPressure > 80)
        {
            weekOneFlags++;
        }

        //Count flags for unusual Blood Sugar
        if(firstBloodSugar > 200 || firstBloodSugar < 60)
        {
            weekOneFlags++;
        }

        //Count flags for unusual Heart Rate
        if(firstHeartRate < 50 || firstHeartRate > 110)
        {
            weekOneFlags++;
        }

        //Count flags for unusual Body Temp
        if(firstBodyTemp < 35.0 || firstBodyTemp > 38.3)
        {
            weekOneFlags++;
        }

        //COUNT FLAGS FOR WEEK TWO////////////////////////////////////////

        //Count flags for unusual Blood Pressure
        if(secondSystolicPressure < 90 || secondSystolicPressure > 130)
        {
            weekTwoFlags++;
        }

        if(secondDiastolicPressure < 60 || secondDiastolicPressure > 80)
        {
            weekTwoFlags++;
        }

        //Count flags for unusual Blood Sugar
        if(secondBloodSugar > 200 || secondBloodSugar < 60)
        {
            weekTwoFlags++;
        }

        //Count flags for unusual Heart Rate
        if(secondHeartRate < 50 || secondHeartRate > 110)
        {
            weekTwoFlags++;
        }

        //Count flags for unusual Body Temp
        if(secondBodyTemp < 35.0 || secondBodyTemp > 38.3)
        {
            weekTwoFlags++;
        }






        //Trigger alert window
        if(weekTwoFlags > weekOneFlags)
        {
            DeclineAlertWindow.openDeclineAlertWindow();
        }

    }

    public static void medicationStatusAlgorithm()
    {

        //Variables

    }

}
