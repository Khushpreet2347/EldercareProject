

public class Main
{
    public static void main(String[] args)
    {





    }
}


//CHECKLIST

/*

- SQL Connector Class
- Driver Class

CLASSES

- Manager Class
- Resident Class
- Caregiver Class
- HealthRecord Class
- Activity Class
- Report Class
-


GUI WINDOWS
- Login window (CREATED, NEEDS SQL LOGIC)
- Logout window (CREATE)
- Health decline window (CREATED, NEEDS SQL LOGIC)
- Med missed/late window (CREATED, NEEDS SQL LOGIC)
- Main menu window
- Profile search window (CREATED, CHANGE TO PANEL CARD, ADD SQL LOGIC)
- Create/delete/edit profile window
- Health record input window
    -> should have a function to allow multiple med input in GUI
- Health record history search and view window
- Activity input window
- Generate and view report window

AI
- Health Decline (GUI window is called in here)
- Missed/Late meds (GUI window is called in here)

 */
