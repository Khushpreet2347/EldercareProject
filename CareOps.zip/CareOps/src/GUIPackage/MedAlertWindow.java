package GUIPackage;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//NOTE: JLabels for ClassPackage.Resident name and E contact will be set in a if condition using data from database

//Med Alert Window class with all JSwing components
public class MedAlertWindow {

    private JButton closeButton;
    private JLabel medDateLabel;
    private JLabel residentNameLabel;
    private JLabel missedLateLabel;
    private JLabel warningLabel;
    private JPanel medAlertPanel;

    //Declare JFrame
    JFrame medWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public MedAlertWindow()
    {

        //Action Listener for the Close Window Button
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                medWindowFrame.dispose();
            }
        });

        //METHOD TO CHANGE MISSED/LATE LABEL TO MATCH WHICH IS WHICH (USES AI)
        /*
        if()
        {
            missedLateLabel.setText("Missed");
        }

        if()
        {
            missedLateLabel.setText("Late")
        }
         */

        //METHOD TO CHANGE RESIDENT LABEL TO RESIDENT NAME (USES SQL)
        //METHOD TO CHANGE DATE LABEL TO MISSED/LATE ENTRY DATE (USES SQL)

    }

    //Method for creating an object to attach form to
    public static void openMedAlertWindow()
    {
        MedAlertWindow medObj = new MedAlertWindow();
        medObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        medWindowFrame.setContentPane(new MedAlertWindow().medAlertPanel);
        medWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        medWindowFrame.setTitle("MEDICINE INPUT ABNORMALITY DETECTED!");
        medWindowFrame.setSize(250, 200);
        medWindowFrame.setLocationRelativeTo(null);
        medWindowFrame.setVisible(true);

    }

}
