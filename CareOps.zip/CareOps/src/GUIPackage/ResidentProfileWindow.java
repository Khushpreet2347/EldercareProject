package GUIPackage;

import javax.swing.*;

public class ResidentProfileWindow
{

    private JPanel residentProfilePanel;
    private JList caregiversList;
    private JSeparator profileSeparator;
    private JLabel profileLabel;
    private JLabel HCNTitleLabel;
    private JLabel fNameTitleLabel;
    private JLabel lNameTitleLabel;
    private JLabel DOBTitleLabel;
    private JLabel emailTitleLabel;
    private JLabel phoneTitleLabel;
    private JLabel eContactNameTitleLabel;
    private JLabel eContactPhoneTitleLabel;
    private JLabel caregiversTitleLabel;
    private JLabel HCNLabel;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel DOBLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JLabel eContactNameLabel;
    private JLabel eContactPhoneLabel;
    private JLabel accountTypeLabel;

    //Declare JFrame
    JFrame residentProfileWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public ResidentProfileWindow()
    {

        //METHOD TO CHANGE PFP LABEL TO ICON (USES SQL)
        //METHOD TO CHANGE WORK ID LABEL (USES SQL)
        //METHOD TO CHANGE FIRST AND LAST NAME LABEL (USES SQL)
        //METHOD TO CHANGE EMAIL LABEL (USES SQL)
        //METHOD TO CHANGE PHONE LABEL (USES SQL)

    }

    //Method for creating an object to attach form to
    public static void openResidentProfileWindow()
    {
        ResidentProfileWindow residentWindowObj = new ResidentProfileWindow();
        residentWindowObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        residentProfileWindowFrame.setContentPane(new ResidentProfileWindow().residentProfilePanel);
        residentProfileWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        residentProfileWindowFrame.setTitle("ClassPackage.Resident Profile");
        //residentProfileWindowFrame.setSize(400, 450);
        residentProfileWindowFrame.setLocationRelativeTo(null);
        residentProfileWindowFrame.setVisible(true);
    }

}
