package GUIPackage;

import ClassPackage.Assignment;
import ClassPackage.Caregiver;
import ClassPackage.Resident;
import DAOPackage.AssignmentDAO;
import DAOPackage.CaregiverDAO;
import DAOPackage.ResidentDAO;

import javax.swing.*;
import java.awt.*;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

public class ResidentProfileWindow
{

    private JPanel residentProfilePanel;
    private DefaultListModel<Caregiver> listModel;
    private JList caregiversList;
    private JLabel profileLabel;
    private JLabel HCNTitleLabel;
    private JLabel fNameTitleLabel;
    private JLabel lNameTitleLabel;
    private JLabel DOBTitleLabel;
    private JLabel emailTitleLabel;
    private JLabel phoneTitleLabel;
    private JLabel eContactNameTitleLabel;
    private JLabel eContactPhoneTitleLabel;
    private JLabel caregiversTitleLabel;
    private JLabel HCNLabel;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel DOBLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JLabel eContactNameLabel;
    private JLabel eContactPhoneLabel;
    private JLabel accountTypeLabel;

    //Declare JFrame
    JFrame residentProfileWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public ResidentProfileWindow(Resident resident)
    {

        //Fill labels of the profile using a resident object
        HCNLabel.setText(resident.getHCN());
        fNameLabel.setText(resident.getfName());
        lNameLabel.setText(resident.getlName());
        emailLabel.setText(resident.getEmail());
        phoneLabel.setText(resident.getPhoneNo());
        eContactNameLabel.setText(resident.geteContactFName());
        eContactPhoneLabel.setText(resident.geteContactPhoneNo());

        //Display profile photo
        if(resident.getProfileImage() != null)
        {
            try
            {
                //Grab profile (in blob type form) and extract its byte form
                //NOTE: Resource -> https://stackoverflow.com/questions/6662432/easiest-way-to-convert-a-blob-into-a-byte-array
                //NOTE: OpenAI assisted with these two lines
                Blob blob = resident.getProfileImage();
                byte[] bytes = blob.getBytes(1, (int) blob.length());

                //Convert SQL blob type to an imageicon to scale, then image to set in a label
                ImageIcon residentIcon = new ImageIcon(bytes);
                Image residentImage = residentIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);

                //Set profile image
                profileLabel.setIcon(new ImageIcon((residentImage)));
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Show assignments for profile
        //Create DAO objects to access data from
        AssignmentDAO assignmentDAO = new AssignmentDAO();
        CaregiverDAO caregiverDAO = new CaregiverDAO();

        //Declare a list of assignments to display
        List<Assignment> assignments = assignmentDAO.getAllResidentAssignments(resident.getHCN());

        //Set a list model so profile list can be manipulated
        listModel = new DefaultListModel<>();
        caregiversList.setModel(listModel);

        //Add all assignments via loop
        for (Assignment a : assignments)
        {
            Caregiver caregiver = caregiverDAO.getOneCaregiverViaID(a.getWorkID());

            //Check if null
            if(caregiver != null)
            {
                listModel.addElement(caregiver);
            }
        }

    }

    //Method for creating an object to attach form to
    public static void openResidentProfileWindow(Resident resident)
    {
        ResidentProfileWindow residentWindowObj = new ResidentProfileWindow(resident);
        residentWindowObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        residentProfileWindowFrame.setContentPane(residentProfilePanel);
        residentProfileWindowFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        residentProfileWindowFrame.setTitle("Resident Profile");
        residentProfileWindowFrame.setSize(800, 600);
        residentProfileWindowFrame.setLocationRelativeTo(null);
        residentProfileWindowFrame.setVisible(true);
    }

}
