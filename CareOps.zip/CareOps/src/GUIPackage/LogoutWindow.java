package GUIPackage;

import javax.swing.*;

public class LogoutWindow
{

    private JPanel logoutPanel;
    private JLabel logoutLabel;

    //Declare JFrame
    JFrame logoutWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public LogoutWindow()
    {

    }

    //Method for creating an object to attach form to
    public static void openLogoutWindow()
    {
        LogoutWindow logoutObj = new LogoutWindow();
        logoutObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        logoutWindowFrame.setContentPane(new LogoutWindow().logoutPanel);
        logoutWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        logoutWindowFrame.setTitle("Care Ops | Logout");
        logoutWindowFrame.setSize(900, 900);
        logoutWindowFrame.setLocationRelativeTo(null);
        logoutWindowFrame.setVisible(true);

    }

}
