package GUIPackage;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogoutWindow
{

    private JPanel logoutPanel;
    private JLabel logoutLabel;
    private JButton exitButton;

    //Declare JFrame
    JFrame logoutWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public LogoutWindow()
    {

        exitButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                logoutWindowFrame.dispose();
            }
        });

    }

    //Method for creating an object to attach form to
    public static void openLogoutWindow()
    {
        LogoutWindow logoutObj = new LogoutWindow();
        logoutObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        logoutWindowFrame.setContentPane(this.logoutPanel);
        logoutWindowFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        logoutWindowFrame.setTitle("Care Ops | Logout");
        logoutWindowFrame.setSize(1000, 600);
        logoutWindowFrame.setLocationRelativeTo(null);
        logoutWindowFrame.setVisible(true);

    }

}
