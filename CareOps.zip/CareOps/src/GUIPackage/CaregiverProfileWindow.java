package GUIPackage;
//LABEL WILL HAVE AN IMAGE ICON ATTACH TO IT THAT WILL BE CONVERTED

import ClassPackage.Assignment;
import ClassPackage.Caregiver;
import ClassPackage.Resident;
import DAOPackage.AssignmentDAO;
import DAOPackage.ResidentDAO;

import javax.swing.*;
import java.awt.*;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

public class CaregiverProfileWindow
{

    private JLabel accountTitleLabel;
    private DefaultListModel<Resident> listModel;
    private JList residentsJList;
    private JLabel profileLabel;
    private JLabel workIDTitleLabel;
    private JLabel fNameTitleLabel;
    private JLabel lNameTitleLabel;
    private JLabel emailTitleLabel;
    private JLabel phoneTitleLabel;
    private JLabel workIDLabel;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JLabel residentsTitleLabel;
    private JPanel caregiverProfilePanel;

    //Declare JFrame
    JFrame caregiverProfileWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public CaregiverProfileWindow(Caregiver caregiver)
    {

        //Fill labels of the profile using a caregiver object
        workIDLabel.setText(caregiver.getWorkID());
        fNameLabel.setText(caregiver.getfName());
        lNameLabel.setText(caregiver.getlName());
        emailLabel.setText(caregiver.getEmail());
        phoneLabel.setText(caregiver.getPhoneNo());

        //Display profile photo
        if(caregiver.getProfileImage() != null)
        {
            try
            {
                //Grab profile (in blob type form) and extract its byte form
                //NOTE: OpenAI assisted with these two lines
                Blob blob = caregiver.getProfileImage();
                byte[] bytes = blob.getBytes(1, (int) blob.length());

                //Convert SQL blob type to an imageicon to scale, then image to set in a label
                ImageIcon caregiverIcon = new ImageIcon(bytes);
                Image caregiverImage = caregiverIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);

                //Set profile image
                profileLabel.setIcon(new ImageIcon((caregiverImage)));
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Show assignments for profile
        //Create DAO objects to access data from
        AssignmentDAO assignmentDAO = new AssignmentDAO();
        ResidentDAO residentDAO = new ResidentDAO();

        //Declare a list of assignments to display
        List<Assignment> assignments = assignmentDAO.getAllCaregiverAssignments(caregiver.getWorkID());

        //Set a list model so profile list can be manipulated
        listModel = new DefaultListModel<>();
        residentsJList.setModel(listModel);

        //Add all assignments via loop
        for(Assignment a : assignments)
        {
            Resident resident = residentDAO.getOneResidentViaID(a.getHCN());

            //Check if null
            if(resident != null)
            {
                listModel.addElement(resident);
            }
        }

    }

    //Method for creating an object to attach form to
    public static void openCaregiverProfileWindow(Caregiver caregiver)
    {
        CaregiverProfileWindow caregiverWindowObj = new CaregiverProfileWindow(caregiver);
        caregiverWindowObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        caregiverProfileWindowFrame.setContentPane(caregiverProfilePanel);
        caregiverProfileWindowFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        caregiverProfileWindowFrame.setTitle("Caregiver Profile");
        caregiverProfileWindowFrame.setSize(400, 450);
        caregiverProfileWindowFrame.setLocationRelativeTo(null);
        caregiverProfileWindowFrame.setVisible(true);
    }

}
