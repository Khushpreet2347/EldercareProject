package GUIPackage;

import ClassPackage.Manager;
import DAOPackage.ManagerDAO;
import MainPackage.PasswordUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogInWindow
{

    private JPanel loginPanel;
    private JTextField workIDTextBox;
    private JTextField passwordTextBox;
    private JLabel careOpsTitleLabel;
    private JLabel workIDTitleLabel;
    private JLabel passwordTitleLabel;
    private JLabel logoLabel;
    private JButton createAccountButton;
    private JButton logInButton;

    //Declare JFrame
    JFrame loginWindowFrame = new JFrame();

    //Variables
    private int loginAttemptCount = 3;

    //Class holding methods for JFrame
    public LogInWindow()
    {

        //USER LOG IN BUTTON
        logInButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

                //GET USER INPUT
                String workIDInput = workIDTextBox.getText();
                String passwordInput = passwordTextBox.getText();

                //CHECK EMPTY FIELDS
                if(workIDInput.isEmpty() || passwordInput.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Please enter your login details");
                    return;
                }

                try
                {
                    ManagerDAO mDAO = new ManagerDAO();

                    //GET MANAGER FROM DATABASE
                    Manager manager = mDAO.getOneManagerViaID(workIDInput);

                    if(manager == null)
                    {
                        JOptionPane.showMessageDialog(null, "Invalid ID or password");
                        loginAttemptCount--;
                    }
                    else
                    {
                        String storedHash = manager.getPasswordHash();

                        //VERIFY PASSWORD - hashing
                        boolean match = PasswordUtil.verifyPassword(passwordInput, storedHash);

                        if(match)
                        {
                            ManagerMenuWindow.openMainMenuWindow();
                            loginWindowFrame.dispose();
                            return;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null, "Invalid ID or password");
                            loginAttemptCount--;
                        }
                    }

                    //ATTEMPT LIMIT
                    if(loginAttemptCount == 0)
                    {
                        JOptionPane.showMessageDialog(loginWindowFrame,
                                "Login attempts limit reached, please contact Admin");
                        loginWindowFrame.dispose();
                        System.exit(0);
                    }

                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }

            }
        });

        //CREATE ACCOUNT BUTTON
        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CreateManagerAcctWindow.openCreateManagerWindow();
            }
        });

    }

    //Method for creating an object to attach form to
    public static void openLoginWindow()
    {
        LogInWindow loginObj = new LogInWindow();
        loginObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        loginWindowFrame.setContentPane(this.loginPanel);
        loginWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginWindowFrame.setTitle("Care Ops | Login");
        loginWindowFrame.setSize(250, 200);
        loginWindowFrame.setLocationRelativeTo(null);
        loginWindowFrame.setVisible(true);
    }

}