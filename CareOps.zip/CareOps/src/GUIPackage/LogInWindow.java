package GUIPackage;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogInWindow
{

    private JPanel loginPanel;
    private JTextField workIDTextBox;
    private JTextField passwordTextBox;
    private JLabel careOpsTitleLabel;
    private JLabel workIDTitleLabel;
    private JLabel passwordTitleLabel;
    private JLabel logoLabel;
    private JButton createAccountButton;

    //Declare JFrame
    JFrame loginWindowFrame = new JFrame();

    //Variables
    private String workIDInput = "";
    private String passwordInput = "";

    private String workID = "";
    private String password = "";

    //Class holding methods for JFrame
    public LogInWindow()
    {

        //Action Listener for the Create Account Window
        //Will launch another window to create an account
        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                CreateManagerAcctWindow.openCreateManagerWindow();
            }
        });

        //Action Listener for the Work ID Text Field
        workIDTextBox.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                //SHOULD COMPARE ENTERED WORK ID
                //SAVE WORK ID TO A VARIABLE TO USE IN PASSWORD LISTENER
                workIDInput = workIDTextBox.getText();


            }
        });

        //Action Listener for the Password Text Field
        passwordTextBox.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                //SHOULD COMPARE ENTERED PASSWORD TO PASSWORD IN DATABASE PAIRED WITH
                //THE WORK ID
                passwordInput = passwordTextBox.getText();



            }
        });

    }

    //Method for creating an object to attach form to
    public static void openLoginWindow()
    {
        LogInWindow loginObj = new LogInWindow();
        loginObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        loginWindowFrame.setContentPane(new LogInWindow().loginPanel);
        loginWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginWindowFrame.setTitle("Care Ops | Login");
        loginWindowFrame.setSize(250, 200);
        loginWindowFrame.setLocationRelativeTo(null);
        loginWindowFrame.setVisible(true);

    }

}
