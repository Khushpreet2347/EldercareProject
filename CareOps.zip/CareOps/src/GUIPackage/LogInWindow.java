package GUIPackage;

import ClassPackage.Manager;
import DAOPackage.ManagerDAO;
import MainPackage.CurrentSession;
import MainPackage.PasswordUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogInWindow
{

    private JPanel loginPanel;
    private JTextField workIDTextBox;
    private JPasswordField passwordTextBox;
    private JLabel careOpsTitleLabel;
    private JLabel workIDTitleLabel;
    private JLabel passwordTitleLabel;
    private JLabel logoLabel;
    private JButton createAccountButton;
    private JButton logInButton;

    //Declare JFrame
    JFrame loginWindowFrame = new JFrame();

    //Variables
    private int loginAttemptCount = 5;

    //Class holding methods for JFrame
    public LogInWindow()
    {

        //USER LOG IN BUTTON
        logInButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

                //GET USER INPUT
                String workIDInput = workIDTextBox.getText().trim();
                String passwordInput = new String(passwordTextBox.getPassword()).trim();

                //CHECK EMPTY FIELDS
                if(workIDInput.isEmpty() || passwordInput.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Please enter all your login details");
                    return;
                }

                //Create a DAO object to access database stored Managers
                ManagerDAO mDAO = new ManagerDAO();

                //GET MANAGER FROM DATABASE
                Manager manager = mDAO.getOneManagerViaID(workIDInput);

                //Set a match flag
                boolean match = false;

                if(manager != null)
                {
                    //Get hashed password and store in a variable
                    String storedHash = manager.getPasswordHash();

                    //VERIFY PASSWORD - hashing
                    match = PasswordUtil.verifyPassword(passwordInput, storedHash);
                }

                if(match)
                {

                    //Store the current Manager user in a session
                    //This allows the user to edit their own profile if they choose to do so
                    CurrentSession.currentManager = manager;

                    ManagerMenuWindow.openMainMenuWindow();
                    loginWindowFrame.dispose();
                }
                else
                {
                    loginAttemptCount--;
                    JOptionPane.showMessageDialog(null, "Account error, please contact the Admin");

                    //ATTEMPT LIMIT REACHED
                    if(loginAttemptCount == 0)
                    {
                        JOptionPane.showMessageDialog(loginWindowFrame,
                                "Login attempts limit reached, please contact Admin");
                        loginWindowFrame.dispose();
                    }
                }
            }
        });

        //ALLOWS USER TO LOG IN BY PRESSING THE "ENTER" KEY ON THEIR KEYBOARD
        passwordTextBox.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                logInButton.doClick();
            }
        });

        //CREATE ACCOUNT BUTTON
        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CreateManagerAcctWindow.openCreateManagerWindow();
            }
        });
    }

    //Method for creating an object to attach form to
    public static void openLoginWindow()
    {
        LogInWindow loginObj = new LogInWindow();
        loginObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        loginWindowFrame.setContentPane(this.loginPanel);
        loginWindowFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        loginWindowFrame.setTitle("Care Ops | Login");
        loginWindowFrame.setSize(500, 400);
        loginWindowFrame.setLocationRelativeTo(null);
        loginWindowFrame.setVisible(true);
    }

}