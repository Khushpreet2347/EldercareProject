package GUIPackage;

import javax.swing.*;

public class ManagerMenuWindow
{

    //Root panel to attach and switch "cards" (sub panels) in and out of
    private JPanel rootPanel;

    //MAIN MENU PANEL COMPONENTS | mm
    private JPanel mainMenuPanel;
    private JButton mmProfileButton;
    private JButton mmRecordsButton;
    private JButton mmActivitiesButton;
    private JButton mmReportsButton;
    private JList mmSelectionList;
    private JButton mmLogoutButton;
    private JLabel mmTitleLabel;
    private JLabel mmLogoLabel;
    private JLabel mmIconLabel;

    //PROFILE SEARCH PANEL COMPONENTS | ps
    private JPanel profileSearchPanel;
    private ButtonGroup profileSearchRadioGroup;
    private JRadioButton psCaregiverRadioButton;
    private JRadioButton psResidentRadioButton;
    private JRadioButton psManagerRadioButton;
    private JTextField psNameTextBox;
    private JTextField psNumberTextBox;
    private JButton psSearchButton;
    private JButton psClearButton;
    private JList psResultList;
    private JSeparator psSeparator;
    private JLabel psTitleLabel;
    private JLabel psNameLabel;
    private JLabel psNumberLabel;
    private JToolBar psToolBar;

    //PROFILE MANAGEMENT PANEL COMPONENTS | pm
    private JPanel profileManagementPanel;
    private JLabel pmTitleLabel;
    private JRadioButton pmModifyRadioButton;
    private JRadioButton pmDeleteRadioButton;
    private JRadioButton pmCreateRadioButton;
    private JComboBox pmTypeComboBox;
    private JTextField pmSearchTextBox;
    private JButton pmSearchButton;
    private JSeparator pmSeparator;
    private JTextField pmIDTextBox;
    private JTextField pmEContactTextBox;
    private JTextField pmEPhoneTextBox;
    private JTextField pmDOBTextBox;
    private JTextField pmFNameTextBox;
    private JTextField pmLNameTextBox;
    private JTextField pmEmailTextBox;
    private JTextField pmPhoneTextBox;
    private JLabel pmIDLabel;
    private JLabel pmFNameLabel;
    private JLabel pmLNameLabel;
    private JLabel pmEmailLabel;
    private JLabel pmPhoneLabel;
    private JLabel pmDOBLabel;
    private JLabel pmEContactLabel;
    private JLabel pmEPhoneLabel;
    private JLabel pmPFPLabel;
    private JSeparator pmSeparatorTwo;
    private JTextField pmAssignmentTextBox;
    private JButton pmRemoveButton;
    private JButton pmAddButton;
    private JList pmAssignmentList;
    private JButton pmClearButton;
    private JSeparator pmSeparatorThree;
    private JLabel pmAssignmentLabel;
    private JButton pmSaveButton;
    private JToolBar pmToolBar;

    //MANAGER PROFILE EDIT PANEL COMPONENTS | me
    private JPanel managerEditPanel;
    private JLabel meTitleLabel;
    private JTextField meFNameTextBox;
    private JTextField meLNameTextBox;
    private JTextField meEmailTextBox;
    private JTextField meIDTextBox;
    private JLabel meIDLabel;
    private JLabel meFNameLabel;
    private JLabel meLNameLabel;
    private JLabel meEmailLabel;
    private JTextField mePhoneTextBox;
    private JLabel mePhoneLabel;
    private JSeparator meSeparator;
    private JButton meSaveButton;
    private JButton meClearButton;
    private JToolBar meToolBar;

    //RECORD SEARCH PANEL COMPONENTS | rs
    private JPanel recordSearchPanel;
    private JToolBar rsToolBar;
    private ButtonGroup healthRecordCheckGroup;
    private JLabel rsTitleLabel;
    private JCheckBox rsDateCheckBox;
    private JTextField rsDateTextbox;
    private JSeparator rsSeparator;
    private JSplitPane rsSpiltPane;
    private JList rsResultList;
    private JTable rsResultTable;
    private JTextField rsNameTextBox;
    private JTextField rsMedStatusTextbox;
    private JCheckBox rsMedStatusCheckBox;
    private JCheckBox rsNameCheckBox;

    //RECORD MANAGEMENT PANEL | rm
    private JPanel recordManagementPanel;
    private JTabbedPane rmTabbedPanel;
    private JPanel rmInputTab;
    private JPanel rmEditTab;
    private JPanel rmDeleteTab;
    private JToolBar rmToolBar;
    //INPUT TAB | iTab

    //EDIT TAB | eTab

    //DELETE TAB | dTab
    private JLabel dTabTitleLabel;
    private JTextField dTabMedNameTextBox;
    private JTextField dTabNameTextBox;
    private JTextField dTabDateTextBox;
    private JComboBox dTabMedStatusComboBox;
    private JCheckBox dTabNameCheckBox;
    private JCheckBox dTabDateCheckBox;
    private JCheckBox dTabMedNameCheckBox;
    private JCheckBox dTabMedStatusCheckBox;
    private JButton dTabClearButton;
    private JButton dTabSearchButton;
    private JSeparator dTabSeparator;
    private JList dTabResultList;

    //ACTIVITY SEARCH PANEL | as
    private JPanel activitySearch;
    private JPanel reportGeneratePanel;
    private JLabel asTitleLabel;
    private JTextField asSearchTextBox;
    private JLabel asActivityTitleLabel;
    private JSeparator asSeparator;
    private JSplitPane asSpiltPane;
    private JList asResultList;
    private JTable asResultTable;
    private JToolBar asToolBar;

    //ACTIVITY MANAGEMENT PANEL | am
    private JPanel activityManagementPanel;
    private JLabel amTitleLabel;
    private JRadioButton amModifyRadioButton;
    private JRadioButton amDeleteRadioButton;
    private JRadioButton amCreateRadioButton;
    private JTextField amSearchTextBox;
    private JButton amSearchButton;
    private JSeparator amSeparator;
    private JTextField amTitleTextBox;
    private JLabel amActivityTitleLabel;
    private JTextField amDateTextBox;
    private JLabel amDateLabel;
    private JLabel amTimeLabel;
    private JTextField amTimeTextBox;
    private JLabel amDescriptionLabel;
    private JLabel amNotesLabel;
    private JLabel amStatusLabel;
    private JComboBox amStatusComboBox;
    private JSeparator amSeparatorTwo;
    private JButton amSaveButton;
    private JButton amClearButton;
    private JTextArea amDescriptionTextArea;
    private JTextArea amNotesTextArea;
    private JToolBar amToolBar;

    //REPORT GENERATE PANEL | rg
    private JLabel rgTitleLabel;
    private JSplitPane rgSplitPane;
    private JTable rgLeftTable;
    private JTable rgRightTable;
    private JButton rgGenerateButton;
    private JTextField rgYearTextBox;
    private JTextField rgMonthTextBox;
    private JCheckBox rgMonthCheckBox;
    private JCheckBox rgYearCheckBox;
    private JRadioButton rgUserMedRadioButton;
    private JRadioButton rgHealthIrregRadioButton;
    private JToolBar rgToolBar;

    //Declare JFrame
    JFrame managerMenuWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public ManagerMenuWindow()
    {

        //METHODS FOR MAIN MENU | mm

        //METHODS FOR PROFILE SEARCH | ps

        //METHODS FOR PROFILE MANAGEMENT | pm

        //METHODS FOR MANAGER PROFILE EDIT | me

        //METHODS FOR RECORD SEARCH | rs

        //METHODS FOR RECORD MANAGEMENT | rm

        //INSERT TAB
        //EDIT TAB
        //DELETE TAB

        //METHODS FOR ACTIVITY SEARCH | as

        //METHODS FOR ACTIVITY MANAGEMENT | am

        //METHODS FOR REPORT GENERATE | rg


    }

    //MainPackage.Main method for creating an object to attach form to
    public static void main(String[] args)
    {
        ManagerMenuWindow managerMenuObj = new ManagerMenuWindow();
        managerMenuObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        //SET CONTENT PANE HERE
        //managerMenuWindowFrame.setContentPane(new ProfileSearchWindow().profileSearchPanel);


    }

}
