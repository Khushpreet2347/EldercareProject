package GUIPackage;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ManagerMenuWindow
{

    //MAIN MENU PANEL COMPONENTS | mm
    private JPanel mainMenuPanel;
    private JButton mmProfileButton;
    private JButton mmRecordsButton;
    private JButton mmActivitiesButton;
    private JButton mmReportsButton;
    private DefaultListModel<String> mmListModel;
    private JList<String> mmSelectionList;
    private JButton mmLogoutButton;
    private JLabel mmTitleLabel;
    private JLabel mmLogoLabel;
    private JLabel mmIconLabel;

    //PROFILE SEARCH PANEL COMPONENTS | ps
    private JPanel profileSearchPanel;
    private ButtonGroup profileSearchRadioGroup;
    private JRadioButton psCaregiverRadioButton;
    private JRadioButton psResidentRadioButton;
    private JRadioButton psManagerRadioButton;
    private JTextField psNameTextBox;
    private JTextField psIDTextBox;
    private JButton psSearchButton;
    private JButton psClearButton;
    private JList psResultList;
    private JSeparator psSeparator;
    private JLabel psTitleLabel;
    private JLabel psNameLabel;
    private JLabel psIDLabel;
    private JToolBar psToolBar;
    private JButton psToolBarBackButton;

    //PROFILE MANAGEMENT PANEL COMPONENTS | pm
    private JPanel profileManagementPanel;
    private JLabel pmTitleLabel;
    private JRadioButton pmModifyRadioButton;
    private JRadioButton pmDeleteRadioButton;
    private JRadioButton pmCreateRadioButton;
    private JComboBox pmTypeComboBox;
    private JTextField pmSearchTextBox;
    private JButton pmSearchButton;
    private JSeparator pmSeparator;
    private JTextField pmIDTextBox;
    private JTextField pmEContactTextBox;
    private JTextField pmEPhoneTextBox;
    private JTextField pmDOBTextBox;
    private JTextField pmFNameTextBox;
    private JTextField pmLNameTextBox;
    private JTextField pmEmailTextBox;
    private JTextField pmPhoneTextBox;
    private JLabel pmIDLabel;
    private JLabel pmFNameLabel;
    private JLabel pmLNameLabel;
    private JLabel pmEmailLabel;
    private JLabel pmPhoneLabel;
    private JLabel pmDOBLabel;
    private JLabel pmEContactLabel;
    private JLabel pmEPhoneLabel;
    private JLabel pmPFPLabel;
    private JSeparator pmSeparatorTwo;
    private JTextField pmAssignmentTextBox;
    private JButton pmRemoveButton;
    private JButton pmAddButton;
    private JList pmAssignmentList;
    private JButton pmClearButton;
    private JSeparator pmSeparatorThree;
    private JLabel pmAssignmentLabel;
    private JButton pmSaveButton;
    private JToolBar pmToolBar;
    private JButton pmToolBarBackButton;

    //MANAGER PROFILE EDIT PANEL COMPONENTS | me
    private JPanel managerEditPanel;
    private JLabel meTitleLabel;
    private JTextField meFNameTextBox;
    private JTextField meLNameTextBox;
    private JTextField meEmailTextBox;
    private JTextField meIDTextBox;
    private JLabel meIDLabel;
    private JLabel meFNameLabel;
    private JLabel meLNameLabel;
    private JLabel meEmailLabel;
    private JTextField mePhoneTextBox;
    private JLabel mePhoneLabel;
    private JSeparator meSeparator;
    private JButton meSaveButton;
    private JButton meClearButton;
    private JToolBar meToolBar;
    private JButton meToolBarBackButton;

    //RECORD SEARCH PANEL COMPONENTS | rs
    private JPanel recordSearchPanel;
    private JToolBar rsToolBar;
    private ButtonGroup healthRecordCheckGroup;
    private JLabel rsTitleLabel;
    private JCheckBox rsDateCheckBox;
    private JTextField rsDateTextbox;
    private JSeparator rsSeparator;
    private JSplitPane rsSpiltPane;
    private JList rsResultList;
    private JTable rsResultTable;
    private JTextField rsNameTextBox;
    private JTextField rsMedStatusTextbox;
    private JCheckBox rsMedStatusCheckBox;
    private JCheckBox rsNameCheckBox;
    private JButton rsClearButton;
    private JButton rsSearchButton;
    private JButton rsToolBarBackButton;

    //RECORD MANAGEMENT PANEL | rm
    private JPanel recordManagementPanel;
    private JTabbedPane rmTabbedPanel;
    private JPanel rmInputTab;
    private JPanel rmEditTab;
    private JPanel rmDeleteTab;
    private JToolBar rmToolBar;
    private JButton rmToolBarBackButton;
    //INPUT TAB | iTab

    //EDIT TAB | eTab

    //DELETE TAB | dTab
    private JLabel dTabTitleLabel;
    private JTextField dTabMedNameTextBox;
    private JTextField dTabNameTextBox;
    private JTextField dTabDateTextBox;
    private JComboBox dTabMedStatusComboBox;
    private JCheckBox dTabNameCheckBox;
    private JCheckBox dTabDateCheckBox;
    private JCheckBox dTabMedNameCheckBox;
    private JCheckBox dTabMedStatusCheckBox;
    private JButton dTabClearButton;
    private JButton dTabSearchButton;
    private JSeparator dTabSeparator;
    private JList dTabResultList;

    //ACTIVITY SEARCH PANEL | as
    private JPanel activitySearch;
    private JPanel reportGeneratePanel;
    private JLabel asTitleLabel;
    private JTextField asSearchTextBox;
    private JLabel asActivityTitleLabel;
    private JSeparator asSeparator;
    private JSplitPane asSpiltPane;
    private JList asResultList;
    private JTable asResultTable;
    private JButton asClearButton;
    private JButton asSearchButton;
    private JToolBar asToolBar;
    private JButton asToolBarBackButton;

    //ACTIVITY MANAGEMENT PANEL | am
    private JPanel activityManagementPanel;
    private JLabel amTitleLabel;
    private JRadioButton amModifyRadioButton;
    private JRadioButton amDeleteRadioButton;
    private JRadioButton amCreateRadioButton;
    private JTextField amSearchTextBox;
    private JButton amSearchButton;
    private JSeparator amSeparator;
    private JTextField amTitleTextBox;
    private JLabel amActivityTitleLabel;
    private JTextField amDateTextBox;
    private JLabel amDateLabel;
    private JLabel amTimeLabel;
    private JTextField amTimeTextBox;
    private JLabel amDescriptionLabel;
    private JLabel amNotesLabel;
    private JLabel amStatusLabel;
    private JComboBox amStatusComboBox;
    private JSeparator amSeparatorTwo;
    private JButton amSaveButton;
    private JButton amClearButton;
    private JTextArea amDescriptionTextArea;
    private JTextArea amNotesTextArea;
    private JToolBar amToolBar;
    private JButton amToolBarBackButton;

    //REPORT GENERATE PANEL | rg
    private JLabel rgTitleLabel;
    private JSplitPane rgSplitPane;
    private JTable rgLeftTable;
    private JTable rgRightTable;
    private JButton rgGenerateButton;
    private JButton rgClearButton;
    private JTextField rgYearTextBox;
    private JTextField rgMonthTextBox;
    private JCheckBox rgMonthCheckBox;
    private JCheckBox rgYearCheckBox;
    private JRadioButton rgUserMedRadioButton;
    private JRadioButton rgHealthIrregRadioButton;
    private JToolBar rgToolBar;
    private JButton rgToolBarBackButton;

    //Declare a root card panel, other card panels will attach to the root
    private JPanel rootPanel;
    private ButtonGroup dTabCheckBoxGroup;
    private ButtonGroup activityManagementRadioGroup;
    private ButtonGroup profileManagementRadioGroup;
    private ButtonGroup reportGenerateRadioGroup;
    private ButtonGroup reportGenerateCheckGroup;
    CardLayout menuCardLayout = new CardLayout();

    //Declare JFrame
    JFrame managerMenuWindowFrame = new JFrame();

    //ADDITIONAL METHODS FOR MENU WINDOWS
    //MAIN MENU METHODS | mm ///////////////////////////////////////////////////////////////////////////////////

    //Method to update the main menu JList selection of options
    private void setMainMenuList(String[] menuOptions)
    {
        mmListModel.clear();
        for(String mo : menuOptions)
        {
            mmListModel.addElement(mo);
        }
    }

    //Class holding methods for JFrame
    public ManagerMenuWindow()
    {

        //METHODS FOR MAIN MENU | mm ///////////////////////////////////////////////////////////////////////////////////

        //SET UP FOR CARD SWITCHING IN JFRAME
        //Set card layout type in the root panel, then add panels with constraints
        rootPanel.setLayout(menuCardLayout);
        rootPanel.add(mainMenuPanel, "MAIN_MENU");
        rootPanel.add(profileSearchPanel, "PROFILE_SEARCH");
        rootPanel.add(profileManagementPanel, "PROFILE_MANAGEMENT");
        rootPanel.add(managerEditPanel, "PROFILE_MANAGER_EDIT");
        rootPanel.add(recordSearchPanel, "RECORD_SEARCH");
        rootPanel.add(recordManagementPanel, "RECORD_MANAGEMENT");
        rootPanel.add(activitySearch, "ACTIVITY_SEARCH");
        rootPanel.add(activityManagementPanel, "ACTIVITY_MANAGEMENT");
        rootPanel.add(reportGeneratePanel, "REPORT_GENERATE");

        //SHOW MAIN MENU TO USER
        menuCardLayout.show(rootPanel, "MAIN_MENU");

        //SWITCHING "CARDS"/WINDOWS IN THE MAIN MENU
        //Declare a list model (allows a list to be edited)
        mmListModel = new DefaultListModel<>();
        mmSelectionList.setModel(mmListModel);

        //Menu arrays for option display in JList (Buttons will use these)
        String profileOptions[] = {"Profile Search", "Profile Management", "Edit Your Profile"};
        String recordOptions[] = {"Record Search", "Record Management"};
        String activityOptions[] = {"Activity Search", "Activity Management"};
        String reportOptions[] = {"Generate Report"};

        //Button Functions to change JList sub menu options
        mmProfileButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setMainMenuList(profileOptions);
            }
        });

        mmRecordsButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setMainMenuList(recordOptions);
            }
        });

        mmActivitiesButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setMainMenuList(activityOptions);
            }
        });

        mmReportsButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setMainMenuList(reportOptions);
            }
        });

        //Menu list options
        //Menu sub options after button option selection, each selection will change cards and bring the user
        //to their desired screen ex. User wishes to access Profile Search window, they will click
        //the Profile button, then the JList will display Profile sub options, user will select
        //Profile Search from JList and JFrame will switch cards to show Profile Search content
        mmSelectionList.addListSelectionListener(new ListSelectionListener()
        {
            @Override
            public void valueChanged(ListSelectionEvent e)
            {

                //Check user selection in JList if there is a selection at all
                String subMenuOption = mmSelectionList.getSelectedValue();
                if(subMenuOption == null) { return; }

                //Switch cards in frame based on selection
                switch(subMenuOption)
                {

                    case "Profile Search":
                            menuCardLayout.show(rootPanel, "PROFILE_SEARCH");
                        break;
                    case "Profile Management":
                            menuCardLayout.show(rootPanel, "PROFILE_MANAGEMENT");
                        break;
                    case "Edit Your Profile":
                            menuCardLayout.show(rootPanel, "PROFILE_MANAGER_EDIT");
                        break;
                    case "Record Search":
                            menuCardLayout.show(rootPanel, "RECORD_SEARCH");
                        break;
                    case "Record Management":
                            menuCardLayout.show(rootPanel, "RECORD_MANAGEMENT");
                        break;
                    case "Activity Search":
                            menuCardLayout.show(rootPanel, "ACTIVITY_SEARCH");
                        break;
                    case "Activity Management":
                            menuCardLayout.show(rootPanel, "ACTIVITY_MANAGEMENT");
                        break;
                    case "Generate Report":
                            menuCardLayout.show(rootPanel, "REPORT_GENERATE");
                        break;
                }
            }
        });

        //LOG OUT USER BUTTON
        mmLogoutButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                managerMenuWindowFrame.dispose();
                LogoutWindow.openLogoutWindow();
            }
        });

        //METHODS FOR PROFILE SEARCH | ps ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        psToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //CLEAR INPUT BUTTON
        psClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                psResidentRadioButton.isSelected();
                psNameTextBox.setText("");
                psIDTextBox.setText("");
            }
        });

        //SEARCH PROFILES BUTTON
        psSearchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                psResultList.removeAll();

            }
        });

        //METHODS FOR PROFILE MANAGEMENT | pm ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        pmToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //POPULATE PROFILE TYPE COMBOBOX
        pmTypeComboBox.addItem("Resident");
        pmTypeComboBox.addItem("Caregiver");
        pmTypeComboBox.setSelectedIndex(-1);


        //FIXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        if(pmTypeComboBox.getSelectedItem() == "Resident")
        {

            pmAssignmentLabel.setText("Caregivers:");

        }

        if(pmTypeComboBox.getSelectedItem() == "Caregiver")
        {
            pmAssignmentLabel.setText("Residents:");
        }

        //CLEAR INPUT BUTTON
        pmClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                pmCreateRadioButton.isSelected();
                pmTypeComboBox.setSelectedIndex(-1);
                pmSearchTextBox.setText("");
                pmIDTextBox.setText("");
                pmFNameTextBox.setText("");
                pmLNameTextBox.setText("");
                pmEmailTextBox.setText("");
                pmPhoneLabel.setText("");
                pmDOBTextBox.setText("");
                pmEContactTextBox.setText("");
                pmEPhoneTextBox.setText("");
                //PFP SELECTION CLEAR HERE






                pmAssignmentTextBox.setText("");
                pmAssignmentList.removeAll();
            }
        });

        //SEARCH PROFILES FOR MANAGING BUTTON
        pmSearchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });

        //REMOVE A ASSIGNMENT BETWEEN RESIDENT/CAREGIVER
        pmRemoveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        //ADD A ASSIGNMENT BETWEEN RESIDENT/CAREGIVER
        pmAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        //SAVE CHANGES TO DATABASE (MODIFY SQL)
        pmSaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        //METHODS FOR MANAGER PROFILE EDIT | me ///////////////////////////////////////////////////////////////////////////////////

        //LOAD CURRENT MANAGER INFO

        //DISABLE WORK ID TEXTBOX (Manager can't change their work ID)
        meIDTextBox.setEnabled(false);

        //CLEAR INPUT BUTTON
        meClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                meFNameLabel.setText("");
                meLNameLabel.setText("");
                meEmailTextBox.setText("");
                mePhoneTextBox.setText("");
            }
        });

        //SAVE ACCOUNT MODIFICATIONS BUTTON
        meSaveButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });

        //TOOLBAR BACK BUTTON METHOD
        meToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //METHODS FOR RECORD SEARCH | rs ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        rsToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //CLEAR INPUT BUTTON
        rsClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                healthRecordCheckGroup.clearSelection();
                rsNameTextBox.setText("");
                rsDateTextbox.setText("");
                rsMedStatusTextbox.setText("");
                rsResultList.removeAll();
                rsResultTable.removeAll();
            }
        });

        //SEARCH RECORDS BUTTON
        rsSearchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });

        //METHODS FOR RECORD MANAGEMENT | rm ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        rmToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //INSERT TAB +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //EDIT TAB +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //DELETE TAB +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        //POPULATE MEDICATION STATUS COMBO BOX
        dTabMedStatusComboBox.addItem("Given");
        dTabMedStatusComboBox.addItem("Late");
        dTabMedStatusComboBox.addItem("Missed");
        dTabMedStatusComboBox.setSelectedIndex(-1);

        //CLEAR INPUT BUTTON
        dTabClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dTabCheckBoxGroup.clearSelection();
                dTabNameTextBox.setText("");
                dTabDateTextBox.setText("");
                dTabMedNameTextBox.setText("");
                dTabMedStatusComboBox.setSelectedIndex(-1);
                dTabResultList.removeAll();
            }
        });

        //SEARCH RECORD TO DELETE BUTTON
        dTabSearchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });

        //METHODS FOR ACTIVITY SEARCH | as ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        asToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //CLEAR INPUT BUTTON
        asClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                asSearchTextBox.setText("");
                asResultList.removeAll();
                asResultTable.removeAll();
            }
        });

        //SEARCH ACTIVITY BUTTON
        asSearchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });

        //METHODS FOR ACTIVITY MANAGEMENT | am ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        amToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //POPULATE COMBO BOX
        amStatusComboBox.addItem("Planned");
        amStatusComboBox.addItem("Ongoing");
        amStatusComboBox.addItem("Completed");
        amStatusComboBox.addItem("Cancelled");
        amStatusComboBox.setSelectedIndex(-1);

        //CLEAR INPUT BUTTON
        amClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                amCreateRadioButton.isSelected();
                amTitleTextBox.setText("");
                amDateTextBox.setText("");
                amTimeTextBox.setText("");
                amDescriptionTextArea.setText("");
                amNotesTextArea.setText("");
                amStatusComboBox.setSelectedIndex(-1);
            }
        });

        //SEARCH ACTIVITY TO MANAGE BUTTON
        amSaveButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });

        //METHODS FOR REPORT GENERATE | rg ///////////////////////////////////////////////////////////////////////////////////

        //TOOLBAR BACK BUTTON METHOD
        rgToolBarBackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                menuCardLayout.show(rootPanel, "MAIN_MENU");
                mmSelectionList.clearSelection();
            }
        });

        //ACTIVATE TEXT BOX FOR YEAR/MONTH
        rgYearTextBox.setEnabled(false);
        rgMonthTextBox.setEnabled(false);

        if(rgYearCheckBox.isSelected())
        {
            rgYearTextBox.setEnabled(true);
        }

        if(rgMonthCheckBox.isSelected())
        {
            rgMonthTextBox.setEnabled(true);
        }

        //CLEAR INPUT BUTTON
        rgClearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                rgUserMedRadioButton.isSelected();
                reportGenerateCheckGroup.clearSelection();
                rgYearTextBox.setText("");
                rgMonthTextBox.setText("");
                rgLeftTable.removeAll();
                rgRightTable.removeAll();
            }
        });

        //GENERATE A REPORT BUTTON
        rgGenerateButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });


    }

    //MainPackage.Main method for creating an object to attach form to
    public static void openMainMenuWindow()
    {
        ManagerMenuWindow managerMenuObj = new ManagerMenuWindow();
        managerMenuObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        //Set up JFrame and Root Panel
        managerMenuWindowFrame.setContentPane(rootPanel);
        menuCardLayout.show(rootPanel, "MAIN_MENU");
        managerMenuWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        managerMenuWindowFrame.setTitle("Care Ops | Main Menu");
        managerMenuWindowFrame.setSize(1000, 950);
        managerMenuWindowFrame.setLocationRelativeTo(null);
        managerMenuWindowFrame.setVisible(true);

    }

}
