package GUIPackage;

import DAOPackage.ManagerDAO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateManagerAcctWindow
{

    private JPanel createManagerAccountPanel;
    private JTextField workIDTextBox;
    private JPasswordField passwordTextBox;
    private JTextField fNameTextBox;
    private JTextField lNameTextBox;
    private JTextField phoneTextBox;
    private JTextField emailTextBox;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JLabel noteLabel;
    private JLabel workIDLabel;
    private JLabel passwordLabel;
    private JButton cancelButton;
    private JButton createAccountButton;

    //Declare JFrame
    JFrame createManagerAcctWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public CreateManagerAcctWindow()
    {

        //Action Listener for the Cancel button
        cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                createManagerAcctWindowFrame.dispose();
            }
        });

        //Action Listener for the Create Account button
        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

                //Save user input to variables
                String inputWorkID = workIDTextBox.getText().trim();
                String inputFName = fNameTextBox.getText().trim();
                String inputLName = lNameTextBox.getText().trim();
                String inputEmail = emailTextBox.getText().trim();
                String inputPhone = phoneTextBox.getText().trim();
                String inputPassword = new String(passwordTextBox.getPassword()).trim();

                //Enforce a password length
                if(inputPassword.length() < 8)
                {
                    JOptionPane.showMessageDialog(null, "Password must be at least 8 characters");
                    return;
                }

                //CHECK USER INPUT
                if(inputWorkID.isEmpty() || inputFName.isEmpty() || inputLName.isEmpty() ||
                        inputEmail.isEmpty() || inputPhone.isEmpty() || inputPassword.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Please fill in all the fields");
                    return;
                }

                //Create DAO object to access database
                ManagerDAO managerDAO = new ManagerDAO();

                //CHECK IF THE USER'S ACCOUNT EXISTS BY WORK ID
                boolean accountExists = managerDAO.managerExistsByWorkID(inputWorkID);

                if(accountExists)
                {
                    JOptionPane.showMessageDialog(null, "This Work ID is already registered.\nPlease use a different one.");
                    return;
                }

                //Create the new manager account
                managerDAO.createManager(inputWorkID, inputFName, inputLName, inputEmail, inputPhone, inputPassword);

                //Inform user of account creation
                JOptionPane.showMessageDialog(null, "Manager account created\nPlease note down your Work ID and Password for the login screen");

                //Close current window
                createManagerAcctWindowFrame.dispose();
            }
        });
    }

    //MainPackage.Main method for creating na object to attach form to
    public static void openCreateManagerWindow()
    {
        CreateManagerAcctWindow createManagerAcctObj = new CreateManagerAcctWindow();
        createManagerAcctObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        createManagerAcctWindowFrame.setContentPane(createManagerAccountPanel);
        createManagerAcctWindowFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        createManagerAcctWindowFrame.setTitle("Create Account");
        createManagerAcctWindowFrame.setSize(550, 500);
        createManagerAcctWindowFrame.setLocationRelativeTo(null);
        createManagerAcctWindowFrame.setVisible(true);
    }

}
