package GUIPackage;

import ClassPackage.Manager;
import DAOPackage.ManagerDAO;

import javax.swing.*;
import java.util.List;

public class ManagerProfileWindow
{

    private JPanel managerProfilePanel;
    private JLabel accountTypeLabel;
    private JLabel workIDTitleLabel;
    private JLabel fNameTitleLabel;
    private JLabel lNameTitleLabel;
    private JLabel emailTitleLabel;
    private JLabel phoneTitleLabel;
    private JLabel workIDLabel;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JSeparator profileSeparator;

    //Declare JFrame
    JFrame managerProfileWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public ManagerProfileWindow(Manager manager)
    {

        //Fill labels of the profile using a manager object
        workIDLabel.setText(manager.getWorkID());
        fNameLabel.setText(manager.getfName());
        lNameLabel.setText(manager.getlName());
        emailLabel.setText(manager.getEmail());
        phoneLabel.setText(manager.getPhoneNo());

    }

    //Method for creating an object to attach form to
    public static void openManagerProfileWindow(Manager manager)
    {
        ManagerProfileWindow managerWindowObj = new ManagerProfileWindow(manager);
        managerWindowObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        managerProfileWindowFrame.setContentPane(managerProfilePanel);
        managerProfileWindowFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        managerProfileWindowFrame.setTitle("Manager Profile");
        managerProfileWindowFrame.setSize(400, 450);
        managerProfileWindowFrame.setLocationRelativeTo(null);
        managerProfileWindowFrame.setVisible(true);
    }

}
