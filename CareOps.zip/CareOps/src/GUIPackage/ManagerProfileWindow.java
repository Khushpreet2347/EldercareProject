package GUIPackage;

import ClassPackage.Manager;
import DAOPackage.ManagerDAO;

import javax.swing.*;
import java.util.List;

public class ManagerProfileWindow
{

    private JPanel managerProfilePanel;
    private JLabel accountTypeLabel;
    private JLabel workIDTitleLabel;
    private JLabel fNameTitleLabel;
    private JLabel lNameTitleLabel;
    private JLabel emailTitleLabel;
    private JLabel phoneTitleLabel;
    private JLabel workIDLabel;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JSeparator profileSeparator;

    //Declare JFrame
    JFrame managerProfileWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public ManagerProfileWindow()
    {

        //Variables to display info in the profile GUI
        int workID;
        String fName;
        String lName;
        String email;
        String phoneNo;

        //Create Manager DAO to pull data from
        ManagerDAO mDAO = new ManagerDAO();
        List<Manager> managers = mDAO.getAllManagers();



        //METHOD TO CHANGE WORK ID LABEL (USES SQL)




        //METHOD TO CHANGE FIRST AND LAST NAME LABEL (USES SQL)
        //METHOD TO CHANGE EMAIL LABEL (USES SQL)
        //METHOD TO CHANGE PHONE LABEL (USES SQL)



    }

    //Method for creating an object to attach form to
    public static void openManagerProfileWindow()
    {
        ManagerProfileWindow managerWindowObj = new ManagerProfileWindow();
        managerWindowObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        managerProfileWindowFrame.setContentPane(new ManagerProfileWindow().managerProfilePanel);
        managerProfileWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        managerProfileWindowFrame.setTitle("ClassPackage.Manager Profile");
        managerProfileWindowFrame.setSize(400, 450);
        managerProfileWindowFrame.setLocationRelativeTo(null);
        managerProfileWindowFrame.setVisible(true);
    }

}
