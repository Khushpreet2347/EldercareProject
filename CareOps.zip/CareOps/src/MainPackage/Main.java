package MainPackage;

import ClassPackage.Caregiver;
import ClassPackage.Manager;
import Connector.SQLConnection;

//TEST
import DAOPackage.CaregiverDAO;
import DAOPackage.ManagerDAO;

import java.sql.*;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {

        //TEST CONNECTION | WORKS!
        /*
        try
        {
            Connection con = SQLConnection.getConnection();

            if(con == null)
            {
                System.out.println("Cannot connect to database");
                return;
            }

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            while(rs.next())
            {
                String id = rs.getString("workID");
                String name = rs.getString("fName");
                String email = rs.getString("email");

                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);
            }

            rs.close();
            stmt.close();
            con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        */


        //TEST
        ManagerDAO mDAO = new ManagerDAO();
        List<Manager> managers = mDAO.getManagers();

        //test
        for(Manager m : managers)
        {
            System.out.println(m);
        }

        System.out.println("\n");

        CaregiverDAO cDAO = new CaregiverDAO();
        List<Caregiver> caregivers = cDAO.getCaregivers();

        for(Caregiver c : caregivers)
        {
            System.out.println(c);
        }


    }
}

//CHECKLIST

/*

HASHING: Was suggested by a friend to use a library that gives you a method to hash a password then store that hash in the database
    -> instead of creating a hash ourselves, was told "we should leave that to the pros"

- SQL Connector Class | DONE

CLASSES

- ClassPackage.Manager Class
- ClassPackage.Resident Class
- ClassPackage.Caregiver Class
- ClassPackage.HealthRecord Class
- Activity Class
- ClassPackage.Report Class
-


GUI WINDOWS
- Login window (CREATED, NEEDS SQL LOGIC)
- Logout window (CREATED)
- Health decline window (CREATED, NEEDS SQL LOGIC)
- Med missed/late window (CREATED, NEEDS SQL LOGIC)
- MainPackage.Main menu window (CREATED, PROFILE INPUT TAB NEEDS A DESIGN)
- Profile search window (CREATED, ADD SQL LOGIC)
- Create/delete/edit profile window (CREATED)
- Health record input window (NEEDS DESIGN)
    -> should have a function to allow multiple med input in GUI
- Health record history search and view window (CREATED)
- Activity input window (CREATED)
- Generate and view report window (CREATED)

AI
- Health Decline (GUI window is called in here)
- Missed/Late meds (GUI window is called in here)

 */
