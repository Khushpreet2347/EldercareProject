package MainPackage;

import GUIPackage.ManagerMenuWindow;
import GUIPackage.LogInWindow;

public class Main
{
    public static void main(String[] args)
    {

        //TEST MAIN MENU
        //ManagerMenuWindow.openMainMenuWindow();

        //Launch Login Window
        LogInWindow.openLoginWindow();


    }
}