package MainPackage;

import  ClassPackage.Manager;

public class CurrentSession
{

    //Current logged in Manager user
    public static Manager currentManager;

}
