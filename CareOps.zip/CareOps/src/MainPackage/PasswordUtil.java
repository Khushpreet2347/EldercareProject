package MainPackage;

import org.mindrot.jbcrypt.BCrypt;

//Uses an external library
public class PasswordUtil
{

    //hash password before saving to db
    public static String hashPassword(String plainPassword)
    {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt());
    }

    //check if login password matches stored hash
    public static boolean verifyPassword(String plainPassword, String hashedPassword)
    {
        if(hashedPassword == null || hashedPassword.isEmpty())
        {
            return false;
        }

        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
}