package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.Condition;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class CondtionDAO
{

    //Method that returns a list of Condition objects to access data from
    public List<Condition> getConditions()
    {

        //Declare a list of Conditions objects
        List<Condition> conditions = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM ConditionRecord");

            //Populate Condition objects
            while(rs.next())
            {
                Condition condition = new Condition
                    (
                        rs.getInt("recordID"),
                        rs.getInt("mood"),
                        rs.getString("painLevel"),
                        rs.getInt("sleepQuality")
                    );

                //Add objects to List
                conditions.add(condition);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Condition objects
        return conditions;

    }
}
