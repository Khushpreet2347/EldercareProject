package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.Report;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ReportDAO
{

    //Method that returns a list of Manager objects to access data from
    public List<Report> getReports()
    {

        //Declare a list of Report objects
        List<Report> reports = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Report");

            //Populate Report objects
            while(rs.next())
            {
                Report report = new Report
                    (
                    rs.getInt("reportID"),
                    rs.getString("type"),
                    rs.getDate("generatedAt"),
                    rs.getString("content")
                    );

                //Add objects to List
                reports.add(report);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Report objects
        return reports;

    }

}
