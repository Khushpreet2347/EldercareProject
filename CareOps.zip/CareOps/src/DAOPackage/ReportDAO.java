package DAOPackage;

import java.sql.*;
import java.sql.Date;
import java.util.*;

import ClassPackage.Report;
import ClassPackage.Resident;
import Connector.SQLConnection;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ReportDAO
{

    //Method that returns a list of report objects to access data from
    public List<Report> getAllReports()
    {

        //Declare a list of Report objects
        List<Report> reports = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Report");

            //Populate Report objects
            while (rs.next())
            {
                Report report = new Report
                (
                    rs.getInt("reportID"),
                    rs.getString("type"),
                    rs.getInt("year"),
                    rs.getInt("month"),
                    rs.getString("content")
                );

                //Add objects to List
                reports.add(report);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Report objects
        return reports;

    }

    //Method that returns one report object to access data from
    public Report getOneReport(String inputType)
    {

        //Declare a report object
        Report report = new Report();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by type
            if (inputType != null && !inputType.trim().isEmpty())
            {
                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM Report WHERE type = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputType);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    report = new Report
                    (
                        rs.getInt("reportID"),
                        rs.getString("type"),
                        rs.getInt("year"),
                        rs.getInt("month"),
                        rs.getString("content")
                    );
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return report object
                return report;
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method to return a list of reports based on type and date(String inputType, int inputYear, int inputMonth
    public List<Report> getReportsViaUserInput(String inputType, Integer inputYear, Integer inputMonth)
    {

        //Declare a list of Reports
        List<Report> reports = new ArrayList<>();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Build a query using a string builder (helps sift through the "content" attribute in the database
            StringBuilder query = new StringBuilder("SELECT * FROM Report WHERE type = ?");

            //Search by year/month
            if(inputYear != null)
            {
                query.append(" AND year = ?");
            }

            if(inputMonth != null)
            {
                query.append(" AND month = ?");
            }

            //Use a prepared statement in order to use user input in the query
            PreparedStatement stmt = con.prepareStatement(query.toString());
            stmt.setString(1, inputType);
            if(inputYear != null)
            {
                stmt.setInt(2, inputYear);
            }
            if(inputMonth != null)
            {
                stmt.setInt(3, inputMonth);
            }

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while(rs.next())
            {
                Report report = new Report
                (
                    rs.getInt("reportID"),
                    rs.getString("type"),
                    rs.getInt("year"),
                    rs.getInt("month"),
                    rs.getString("content")
                );

                //Add objects to list
                reports.add(report);

            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return report object
        return reports;

    }

    //Method to create a report in the database
    public void createReport(String inputType, int inputYear, int inputMonth, String inputContent)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO Report (type, year, month, content) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputType);
            stmt.setInt(2, inputYear);
            stmt.setInt(3, inputMonth);
            stmt.setString(4, inputContent);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

}

