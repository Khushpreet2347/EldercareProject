package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Condition;
import Connector.SQLConnection;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ConditionDAO
{

    //Method that returns a list of Condition objects to access data from
    public List<Condition> getAllConditions()
    {

        //Declare a list of Conditions objects
        List<Condition> conditions = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM ConditionRecord");

            //Populate Condition objects
            while(rs.next())
            {
                Condition condition = new Condition
                    (
                        rs.getInt("recordID"),
                        rs.getInt("mood"),
                        rs.getInt("painLevel"),
                        rs.getInt("sleepQuality")
                    );

                //Add objects to List
                conditions.add(condition);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Condition objects
        return conditions;

    }

    //Method that returns one condition object to access data from
    public Condition getOneCondition(int recordID)
    {

        //Declare a Condition object
        Condition condition = new Condition();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM ConditionRecord WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, recordID);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while(rs.next())
            {
                condition = new Condition
                (
                    rs.getInt("recordID"),
                    rs.getInt("mood"),
                    rs.getInt("painLevel"),
                    rs.getInt("sleepQuality")
                );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return condition object
            return condition;

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method to create a condition in the database
    public void createCondition(int inputRecordID, int inputMood, int inputPainLevel, int inputSleepQuality)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO ConditionRecord (recordID, mood, painLevel, sleepQuality) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputRecordID);
            stmt.setInt(2, inputMood);
            stmt.setInt(3, inputPainLevel);
            stmt.setInt(4, inputSleepQuality);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify a condition in the database
    public void modifyCondition(int inputRecordID, int inputMood, int inputPainLevel, int inputSleepQuality)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "UPDATE ConditionRecord SET mood = ?, painLevel = ?, sleepQuality = ? WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputMood);
            stmt.setInt(2, inputPainLevel);
            stmt.setInt(3, inputSleepQuality);
            stmt.setInt(4, inputRecordID);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete a condition in the database
    public void deleteCondition(int inputRecordID)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "DELETE FROM ConditionRecord WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputRecordID);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

}
