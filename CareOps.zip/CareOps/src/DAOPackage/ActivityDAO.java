package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.Activity;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ActivityDAO
{

    //Method that returns a list of Activity objects to access data from
    public List<Activity> getActivities()
    {

        //Declare a list of Manager objects
        List<Activity> activities = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Activity");

            //Populate Activity objects
            while(rs.next())
            {
                Activity activity = new Activity
                    (
                        rs.getInt("activityID"),
                        rs.getString("type"),
                        rs.getString("description"),
                        rs.getDate("timestamp"),
                        rs.getString("workID"),
                        rs.getString("HCN")
                    );

                //Add objects to List
                activities.add(activity);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Activity objects
        return activities;

    }
}
