package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.Manager;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ManagerDAO
{

    //Method that returns a list of Manager objects to access data from
    public List<Manager> getManagers()
    {

        //Declare a list of Manager objects
        List<Manager> managers = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            //Populate Manager objects
            while(rs.next())
            {
                Manager manager = new Manager
                    (
                        rs.getString("workID"),
                        rs.getString("fName"),
                        rs.getString("lName"),
                        rs.getString("email"),
                        rs.getString("phoneNo"),
                        rs.getString("passwordHash")
                    );

                //Add objects to List
                managers.add(manager);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return managers;

    }

}
