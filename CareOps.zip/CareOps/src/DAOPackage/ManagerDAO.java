package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.Manager;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ManagerDAO
{

    //Method that returns a list of Manager objects to access data from
    public List<Manager> getAllManagers()
    {

        //Declare a list of Manager objects
        List<Manager> managers = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            //Populate Manager objects
            while(rs.next())
            {
                Manager manager = new Manager
                    (
                        rs.getString("workID"),
                        rs.getString("fName"),
                        rs.getString("lName"),
                        rs.getString("email"),
                        rs.getString("phoneNo"),
                        rs.getString("passwordHash")
                    );

                //Add objects to List
                managers.add(manager);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return managers;

    }

    public Manager getOneManager(String inputWorkID, String inputName)
    {

        //Declare a Manager object
        Manager manager = new Manager();

        //Variables to save data to for the object
        int workID;
        String fName;
        String lName;
        String email;
        String phoneNo;

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();

            if (inputWorkID != null)
            {
                ResultSet rs = stmt.executeQuery("SELECT * FROM Manager WHERE workID = " + inputWorkID);

                while (rs.next())
                {
                    manager = new Manager
                    (
                    rs.getString("workID"),
                    rs.getString("fName"),
                    rs.getString("lName"),
                    rs.getString("email"),
                    rs.getString("phoneNo"),
                    rs.getString("passwordHash")
                    );
                }

                return manager;
            }

            if (inputName != null)
            {
                ResultSet rs = stmt.executeQuery("SELECT * FROM Manager WHERE workID = " + inputName);

                while (rs.next())
                {
                    manager = new Manager
                    (
                    rs.getString("workID"),
                    rs.getString("fName"),
                    rs.getString("lName"),
                    rs.getString("email"),
                    rs.getString("phoneNo"),
                    rs.getString("passwordHash")
                    );
                }

                return manager;
            }

            //rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return manager;

    }

}
