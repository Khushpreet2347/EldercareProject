package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.HealthRecord;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class HealthRecordDAO
{

    //Method returns a list of Health Record objects to access data from
    public List<HealthRecord> getHealthRecord()
    {

        //Declare a list of Health Record objects
        List<HealthRecord> healthRecords = new ArrayList<>();

        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            //Populate Health Record objects
            while(rs.next())
            {
                HealthRecord healthRecord = new HealthRecord
                    (
                        rs.getString("HCN"),
                        rs.getInt("recordID"),
                        rs.getString("entryDate"),
                        rs.getString("entryTime"),
                        rs.getString("note")
                    );

                //Add objects to List
                healthRecords.add(healthRecord);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Health Record objects
        return healthRecords;

    }

}
