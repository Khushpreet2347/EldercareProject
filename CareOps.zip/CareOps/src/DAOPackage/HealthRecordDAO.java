package DAOPackage;

import java.sql.*;
import java.sql.Date;
import java.util.*;

import ClassPackage.HealthRecord;
import Connector.SQLConnection;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class HealthRecordDAO
{

    /*//Method returns a list of Health Record objects to access data from
    public List<HealthRecord> getAllHealthRecord()
    {

        //Declare a list of Health Record objects
        List<HealthRecord> healthRecords = new ArrayList<>();

        //Connecto to database
        try
        {

            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM HealthRecord");

            //Populate Health Record objects
            while (rs.next())
            {
                HealthRecord healthRecord = new HealthRecord
                (
                    rs.getInt("recordID"),
                    rs.getString("HCN"),
                    rs.getString("entryDate"),
                    rs.getString("entryTime"),
                    rs.getString("note"),
                    rs.getDate("createdAt")
                );

                //Add objects to List
                healthRecords.add(healthRecord);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Health Record objects
        return healthRecords;

    }*/

    //Method that returns one Health Record object to access data from
    public List<HealthRecord> getAllHealthRecords(String inputFullName, String inputDate, String inputMedStatus)
    {

        //Declare a list of Health Record objects
        List<HealthRecord> healthRecords = new ArrayList<>();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if (inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                    return null;
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM HealthRecord WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    HealthRecord healthRecord = new HealthRecord
                    (
                        rs.getInt("recordID"),
                        rs.getString("HCN"),
                        rs.getDate("entryDate"),
                        rs.getTime("entryTime"),
                        rs.getString("note")
                   );

                    //Add objects to List
                    healthRecords.add(healthRecord);
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return object
                return healthRecords;

            }

            //Search by Date
            if (inputDate != null && !inputDate.trim().isEmpty())
            {
                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM HealthRecord WHERE entryDate = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputDate);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    HealthRecord healthRecord = new HealthRecord
                    (
                        rs.getInt("recordID"),
                        rs.getString("HCN"),
                        rs.getDate("entryDate"),
                        rs.getTime("entryTime"),
                        rs.getString("note")
                    );

                    //Add objects to List
                    healthRecords.add(healthRecord);
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return health record object
                return healthRecords;
            }

            //Search by Medication Status (Uses foreign key and joins tables)
            if (inputMedStatus != null && !inputMedStatus.trim().isEmpty())
            {
                //Use a prepared statement in order to use user input in the query
                //Joins two tables to access med status info
                String query = "SELECT hr *" +
                                "FROM HealthRecord hr" +
                                "JOIN MedicationEntry me" +
                                    "ON hr.recordID = me.recordID" +
                                "WHERE me.status =?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputMedStatus);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    HealthRecord healthRecord = new HealthRecord
                    (
                        rs.getInt("recordID"),
                        rs.getString("HCN"),
                        rs.getDate("entryDate"),
                        rs.getTime("entryTime"),
                        rs.getString("note")
                    );

                    //Add objects to List
                    healthRecords.add(healthRecord);
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return health record object
                return healthRecords;
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method that returns one Health Record object to access data from
    public HealthRecord getOneHealthRecord(String inputFullName, String inputRecordID)
    {

        //Declare a Manager object
        HealthRecord healthRecord = new HealthRecord();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if (inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                    return null;
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM HealthRecord WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    healthRecord = new HealthRecord
                    (
                        rs.getInt("recordID"),
                        rs.getString("HCN"),
                        rs.getDate("entryDate"),
                        rs.getTime("entryTime"),
                        rs.getString("note")
                    );
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return object
                return healthRecord;

            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method to return the name related to a health record using a HCN (uses JOIN tables)
    //This method is in HealthRecordDAO instead of ResidentDAO as a name attribute is not in the HealthRecord SQL table
    public String getResidentNameViaHCN(String HCN)
    {

        //Init a variable to save the name to
        String fullName = "";

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "SELECT fName, lName FROM Resident WHERE HCN = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, HCN);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            if(rs.next())
            {
                fullName = rs.getString("fName") + " " + rs.getString("lName");
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return the name
        return fullName;

    }

    //Method to create a health record in the database
    public void createHealthRecord(String inputHCN, String inputFullName, Date inputEntryDate, Time inputEntryTime, String inputNote, Date inputCreatedAt)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO HealthRecord (HCN, entryDate, entryTime, note) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputHCN);
            stmt.setDate(2, inputEntryDate);
            stmt.setTime(3, inputEntryTime);
            stmt.setString(4, inputNote);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify a health record in the database
    public void modifyHealthRecord(int inputRecordID, String inputHCN, String inputFullName, Date entryDate, Time entryTime, String inputNote, Date inputCreatedAt)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if (inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "UPDATE HealthRecord SET HCN = ?, fName = ?, lName = ?, entryDate = ?, entryTime = ?, note = ?, createdAt = ? WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputHCN);
                stmt.setString(2, fName);
                stmt.setString(3, lName);
                stmt.setDate(4, entryDate);
                stmt.setTime(5, entryTime);
                stmt.setString(6, inputNote);
                stmt.setDate(7, inputCreatedAt);
                stmt.setString(8, fName);
                stmt.setString(9, lName);

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();

            }

            //Search by record ID
            if (inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];
                //Use a prepared statement in order to use user input in the query
                String query = "UPDATE HealthRecord SET HCN = ?, fName = ?, lName = ?, entryDate = ?, entryTime = ?, note = ?, createdAt = ? WHERE recordID = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputHCN);
                stmt.setString(2, fName);
                stmt.setString(3, lName);
                stmt.setDate(4, entryDate);
                stmt.setTime(5, entryTime);
                stmt.setString(6, inputNote);
                stmt.setDate(7, inputCreatedAt);
                stmt.setInt(8, inputRecordID);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Close resources
                rs.close();
                stmt.close();

                //Close connection
                con.close();
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete a health record in the database
    public void deleteHealthRecord(String inputFullName, int inputRecordID)
    {

        //Connect to database
        try {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if (inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "DELETE FROM HealthRecord WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();

            }

            //Search by record ID
            //Use a prepared statement in order to use user input in the query
            String query = "DELETE FROM HealthRecord WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputRecordID);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();

            //Close connection
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

}