package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.HealthRecord;
import Connector.SQLConnection;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class HealthRecordDAO
{

    //Method returns a list of Health Record objects to access data from
    public List<HealthRecord> getHealthRecord()
    {

        //Declare a list of Health Record objects
        List<HealthRecord> healthRecords = new ArrayList<>();

        //Connecto to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM HealthRecord");

            //Populate Health Record objects
            while(rs.next())
            {
                HealthRecord healthRecord = new HealthRecord
                    (
                        rs.getString("HCN"),
                        rs.getInt("recordID"),
                        rs.getString("entryDate"),
                        rs.getString("entryTime"),
                        rs.getString("note")
                    );

                //Add objects to List
                healthRecords.add(healthRecord);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Health Record objects
        return healthRecords;

    }

}

//Method that returns one Health Record object to access data from
public HealthRecord getOneHealthRecord(String inputFullName, String inputDate, String inputMedStatus)
{

    //Declare a Manager object
    HealthRecord healthRecord = new HealthRecord();

    //Connect to database
    try
    {

        Connection con = SQLConnection.getConnection();

        //Search by full name
        if(inputFullName != null && !inputFullName.trim().isEmpty())
        {

            //Split the full name into a first and last name
            String[] nameSplit = inputFullName.trim().split(" ");

            //Check if user entered a full name
            if(nameSplit.length < 2)
            {
                JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                return null;
            }

            //Save split full name to separate variables
            String fName = nameSplit[0];
            String lName = nameSplit[1];

            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM HealthRecord WHERE fName = ? AND lName = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, fName);
            stmt.setString(2, lName);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while (rs.next())
            {
                healthRecord = new HealthRecord
                (
                    rs.getString("HCN"),
                    rs.getInt("recordID"),
                    rs.getString("entryDate"),
                    rs.getString("entryTime"),
                    rs.getString("note")
                );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return object
            return healthRecord;

        }

        //Search by Date
        if(inputDate != null && !inputDate.trim().isEmpty())
        {
            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM HealthRecord WHERE entryDate = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputDate);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while (rs.next())
            {
                healthRecord = new HealthRecord
                (
                    rs.getString("HCN"),
                    rs.getInt("recordID"),
                    rs.getString("entryDate"),
                    rs.getString("entryTime"),
                    rs.getString("note")
                );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return health record object
            return healthRecord;
        }

        //Search by Medication Status (Uses foreign key)
        if(inputMedStatus != null && !inputMedStatus.trim().isEmpty())
        {
            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM HealthRecord WHERE workID = ?";







            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputMedStatus);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while (rs.next())
            {
                healthRecord = new HealthRecord
                (
                    rs.getString("HCN"),
                    rs.getInt("recordID"),
                    rs.getString("entryDate"),
                    rs.getString("entryTime"),
                    rs.getString("note")
                );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return health record object
            return healthRecord;
        }

    }
    catch (SQLException e)
    {
        e.printStackTrace();
    }

    //Return no results if user input does not match any database entries
    return null;

}

//Method to create a health record in the database
public void createHealthRecord(int inputRecordID, String inputHCN, String inputEntryDate, String inputEntryTime, String inputNote)
{

    //Connect to database
    try
    {

        Connection con = SQLConnection.getConnection();

        //Query for creating a new entry into the database
        String query = "INSERT INTO HealthRecord VALUES ('?', '?', '?', '?', '?')";
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setString(1, "inpurRecordID");
        stmt.setString(2, "inputHCN");
        stmt.setString(3, "inputEntryDate");
        stmt.setString(4, "inputEntryTime");
        stmt.setString(5, "inputNote");


        //Execute query
        stmt.executeUpdate();

        //Close resources
        stmt.close();
        con.close();

    }
    catch(SQLException e)
    {
        e.printStackTrace();
    }

}

//Method to modify a health record in the database
public void modifyHealthRecord(String inputFullName, int inputRecordID, String inputHCN, String entryDate, String entryTime, String inputNote)
{

    //Connect to database
    try
    {

        Connection con = SQLConnection.getConnection();

        //Search by full name
        if(inputFullName != null && !inputFullName.trim().isEmpty())
        {

            //Split the full name into a first and last name
            String[] nameSplit = inputFullName.trim().split(" ");

            //Check if user entered a full name
            if (nameSplit.length < 2)
            {
                JOptionPane.showMessageDialog(null, "Please enter a first and last name");
            }

            //Save split full name to separate variables
            String fName = nameSplit[0];
            String lName = nameSplit[1];

            //Use a prepared statement in order to use user input in the query
            String query = "UPDATE HealthRecord SET HCN AND entryDate AND entryTime AND note WHERE fName = ? AND lName = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            //Set string to names (changes ? in statement to names)
            stmt.setString(1, inputHCN);
            stmt.setString(2, entryDate);
            stmt.setString(3, entryTime);
            stmt.setString(4, inputNote);
            stmt.setString(5, fName);
            stmt.setString(6, lName);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Close resources
            rs.close();
            stmt.close();

        }

        //Search by record ID
        //Use a prepared statement in order to use user input in the query
        String query = "UPDATE HealthRecord SET HCN AND entryDate AND entryTime AND note WHERE recordID = ?";
        PreparedStatement stmt = con.prepareStatement(query);
        //Set string to names (changes ? in statement to names)
        stmt.setString(1, inputHCN);
        stmt.setString(2, entryDate);
        stmt.setString(3, entryTime);
        stmt.setString(4, inputNote);
        stmt.setInt(5, inputRecordID);

        //Execute query
        ResultSet rs = stmt.executeQuery();

        //Close resources
        rs.close();
        stmt.close();

        //Close connection
        con.close();

    }
    catch(SQLException e)
    {
        e.printStackTrace();
    }
}

//Method to delete a health record in the database
public void deleteHealthRecord(String inputFullName, int inputRecordID)
{

    //Connect to database
    try
    {

        Connection con = SQLConnection.getConnection();

        //Search by full name
        if(inputFullName != null && !inputFullName.trim().isEmpty())
        {

            //Split the full name into a first and last name
            String[] nameSplit = inputFullName.trim().split(" ");

            //Check if user entered a full name
            if(nameSplit.length < 2)
            {
                JOptionPane.showMessageDialog(null, "Please enter a first and last name");
            }

            //Save split full name to separate variables
            String fName = nameSplit[0];
            String lName = nameSplit[1];

            //Use a prepared statement in order to use user input in the query
            String query = "DELETE FROM HealthRecord WHERE fName = ? AND lName = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, fName);
            stmt.setString(2, lName);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();

        }

        //Search by record ID
        //Use a prepared statement in order to use user input in the query
        String query = "DELETE FROM HealthRecord WHERE recordID =?";
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setInt(1, inputRecordID);

        //Execute query
        stmt.executeUpdate();

        //Close resources
        stmt.close();

        //Close connection
        con.close();

    }
    catch(SQLException e)
    {
        e.printStackTrace();
    }
}

