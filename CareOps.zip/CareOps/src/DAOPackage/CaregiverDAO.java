package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.Caregiver;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class CaregiverDAO
{

    //Method that returns a list of Caregiver objects to access data from
    public List<Caregiver> getCaregivers()
    {

        //Declare a list of Caregiver objects
        List<Caregiver> caregivers = new ArrayList<>();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Caregiver");

            //Populate Caregiver objects
            while(rs.next())
            {
                Caregiver caregiver = new Caregiver
                (
                    rs.getString("workID"),
                    rs.getString("fName"),
                    rs.getString("lName"),
                    rs.getString("email"),
                    rs.getString("phoneNo")
                );

                //Add objects to List
                caregivers.add(caregiver);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Caregiver objects
        return caregivers;

    }

}
