package DAOPackage;

import java.sql.*;
import java.util.*;
import java.sql.Date;

import Connector.SQLConnection;
import ClassPackage.Assignment;
import GUIPackage.ResidentProfileWindow;

import javax.swing.*;
import javax.xml.transform.Result;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class AssignmentDAO
{
    //Method that returns a list of Assignment objects to access data from
    public List<Assignment> getAllAssignment()
    {

        //Declare a list of assignment objects
        List<Assignment> assignments = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Assignment");

            //Populate Assignment objects
            while(rs.next())
            {
                Assignment assignment = new Assignment
                (
                    rs.getString("HCN"),
                    rs.getString("workID"),
                    rs.getString("assignmentID"),
                    rs.getDate("assignedDate")
                );

                //Add objects to List
                assignments.add(assignment);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Assignment objects
        return assignments;

    }

    //Method that returns one assignment object (for a resident) to access data from
    public List<Assignment> getAllResidentAssignments(String inputHCN)
    {

        //Declare a list of assignments
        List<Assignment> assignments = new ArrayList<>();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM Assignment WHERE HCN = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputHCN);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to list
            while(rs.next())
            {
                Assignment assignment = new Assignment
                        (
                          rs.getString("assignmentID"),
                          rs.getString("HCN"),
                          rs.getString("workID"),
                          rs.getDate("assignedDate")
                        );

                assignments.add(assignment);

            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return the list
        return assignments;

    }

    //Method that returns one assignment object (for a caregiver) to access data from
    public List<Assignment> getAllCaregiverAssignments(String inputWorkID)
    {

        //Declare a list of assignments
        List<Assignment> assignments = new ArrayList<>();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM Assignment WHERE workID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputWorkID);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to list
            while(rs.next())
            {
                Assignment assignment = new Assignment
                        (
                                rs.getString("assignmentID"),
                                rs.getString("HCN"),
                                rs.getString("workID"),
                                rs.getDate("assignedDate")
                        );

                assignments.add(assignment);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return the list
        return assignments;

    }

    //Method to assign a Resident or Caregiver to each other
    public void createAssignment(String inputAssignmentID, String inputHCN, String inputWorkID, Date inputAssignedDate)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO Assignment VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputAssignmentID);
            stmt.setString(2, inputHCN);
            stmt.setString(3, inputWorkID);
            stmt.setDate(4, inputAssignedDate);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to delete an assignment in the database
    public void deleteAssignment(String inputID)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by workID or HCN
            if(inputID != null && !inputID.trim().isEmpty())
            {
                //Use a prepared statement in order to use user input in the query
                String query = "DELETE FROM Assignment WHERE workId = ? OR HCN = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputID);
                stmt.setString(2, inputID);

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
            }

            //Close connection
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

}