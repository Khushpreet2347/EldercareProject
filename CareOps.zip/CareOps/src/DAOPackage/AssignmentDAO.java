package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.Assignment;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class AssignmentDAO
{
    //Method that returns a list of Assignment objects to access data from
    public List<Assignment> getAssignment()
    {

        //Declare a list of Manager objects
        List<Assignment> assignments = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Assignment");

            //Populate Assignment objects
            while(rs.next())
            {
                Assignment assignment = new Assignment
                    (
                    rs.getString("HCN"),
                    rs.getString("workID"),
                    rs.getString("assignmentID"),
                    rs.getDate("assignedDate")
                    );

                //Add objects to List
                assignments.add(assignment);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Assignment objects
        return assignments;

    }
}
