package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.VitalSigns;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class VitalSignsDAO
{

    //Method that returns a list of Vital Sign objects to access data from
    public List<VitalSigns> getVitalSigns()
    {

        //Declare a list of Manager objects
        List<VitalSigns> vitalSigns = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM VitalSigns");

            //Populate Vital Sign objects
            while(rs.next())
            {
                VitalSigns vitalSign = new VitalSigns
                        (
                                rs.getInt("recordID"),
                                rs.getInt("bloodPressure"),
                                rs.getInt("bloodSugar"),
                                rs.getDouble("temperature"),
                                rs.getInt("heartRate")
                        );

                //Add objects to List
                vitalSigns.add(vitalSign);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return vitalSigns;

    }

}
