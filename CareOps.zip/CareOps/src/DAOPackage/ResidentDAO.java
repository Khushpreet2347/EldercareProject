package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.Resident;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ResidentDAO
{

    //Method that returns a list of Resident objects to access data from
    public List<Resident> getResidents() {

        //Declare a list Resident objects
        List<Resident> residents = new ArrayList<>();

        //Connect to database
        try {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Resident");

            //Populate Resident objects
            while (rs.next()) {
                Resident resident = new Resident
                        (
                                rs.getString("HCN"),
                                rs.getString("fName"),
                                rs.getString("lName"),
                                rs.getString("dateOfBirth"),
                                rs.getString("email"),
                                rs.getString("phoneNo"),
                                rs.getString("profileImage"),
                                rs.getString("eContactFName"),
                                rs.getString("eContactPhoneNo")
                        );

                //Add objects to List
                residents.add(resident);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //Return a list of Resident objects
        return residents;

    }

}
