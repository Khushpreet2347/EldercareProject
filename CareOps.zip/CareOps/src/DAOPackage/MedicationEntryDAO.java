/*package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.MedicationEntry;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class MedicationEntryDAO
{
    //Method that returns a list of Manager objects to access data from
    public List<MedicationEntry> getMedicationEntry()
    {

        //Declare a list of Medication Entry objects
        List<MedicationEntry> medicationEntries = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MedicationEntry");

            //Populate Manager objects
            while(rs.next())
            {
                MedicationEntry medicationEntry = new MedicationEntry
                    (
                        rs.getInt("recordID"),
                        rs.getInt("medEntryID"),
                        rs.getString("mName"),
                        rs.getDouble("dose"),
                        rs.getString("status"),
                        rs.getString("note"),
                        rs.getTime("time")
                    );

                //Add objects to List
                medicationEntries.add(medicationEntry);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return medicationEntries;

    }
}
*/