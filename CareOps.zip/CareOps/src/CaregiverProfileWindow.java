
//LABEL WILL HAVE AN IMAGE ICON ATTACH TO IT THAT WILL BE CONVERTED

import javax.swing.*;

public class CaregiverProfileWindow
{

    private JLabel accountTitleLabel;
    private JList residentsJList;
    private JLabel profileLabel;
    private JLabel workIDTitleLabel;
    private JLabel fNameTitleLabel;
    private JLabel lNameTitleLabel;
    private JLabel emailTitleLabel;
    private JLabel phoneTitleLabel;
    private JLabel workIDLabel;
    private JLabel fNameLabel;
    private JLabel lNameLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JLabel residentsTitleLabel;
    private JPanel caregiverProfilePanel;

    //Declare JFrame
    JFrame caregiverProfileWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public CaregiverProfileWindow()
    {

        //METHOD TO CHANGE PROFILE LABEL TO ICON FOR PFP (USES SQL)
        //METHOD TO CHANGE WORK ID LABEL (USES SQL)
        //METHOD TO CHANGE FIRST AND LAST NAME LABEL (USES SQL)
        //METHOD TO CHANGE EMAIL LABEL (USES SQL)
        //METHOD TO CHANGE PHONE LABEL (USES SQL)

    }

    //Method for creating an object to attach form to
    public static void openCaregiverProfileWindow()
    {
        CaregiverProfileWindow caregiverWindowObj = new CaregiverProfileWindow();
        caregiverWindowObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        caregiverProfileWindowFrame.setContentPane(new CaregiverProfileWindow().caregiverProfilePanel);
        caregiverProfileWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        caregiverProfileWindowFrame.setTitle("Caregiver Profile");
        //caregiverProfileWindowFrame.setSize(400, 450);
        caregiverProfileWindowFrame.setLocationRelativeTo(null);
        caregiverProfileWindowFrame.setVisible(true);
    }

}
