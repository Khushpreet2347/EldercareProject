import javax.swing.*;

public class ManagerMenuWindow
{

    //Declare JFrame
    JFrame managerMenuWindowFrame = new JFrame();

    //Declare panels
    //Each panel will be switched out in the frame depending on what menu button is selected
    JPanel accountManagerPanel = new JPanel();
    JPanel profileSearchPanel = new JPanel();
    JPanel activityManagerPanel = new JPanel();
    private JPanel rootPanel;
    private JPanel mainMenuPanel;

    //Class holding methods for JFrame
    public ManagerMenuWindow()
    {



    }

    //Main method for creating an object to attach form to
    public static void main(String[] args)
    {
        ManagerMenuWindow managerMenuObj = new ManagerMenuWindow();
        managerMenuObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {

        //SET CONTENT PANE HERE
        //managerMenuWindowFrame.setContentPane(new ProfileSearchWindow().profileSearchPanel);


    }


}
