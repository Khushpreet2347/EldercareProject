import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateManagerAcctWindow
{

    private JPanel createManagerAccountPanel;
    private JTextField workIDTextField;
    private JTextField passwordTextField;
    private JButton cancelButton;
    private JButton createAccountButton;
    private JLabel noteLabel;
    private JLabel workIDTitleLabel;
    private JLabel passwordTitleLabel;

    //Declare JFrame
    JFrame createManagerAcctWindowFrame = new JFrame();

    //Variable
    private String workIDInput = "";
    private String passwordInput = "";

    //Class holding methods for JFrame
    public CreateManagerAcctWindow()
    {

        //Action Listener for the Work ID Text Field
        workIDTextField.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                workIDInput = workIDTextField.getText();
            }
        });

        //Action Listener for the Password Text Field
        passwordTextField.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                passwordInput = passwordTextField.getText();
            }
        });

        //Action Listener for the Cancel button
        cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                createManagerAcctWindowFrame.dispose();
            }
        });

        //Action Listener for the Create Account button
        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                //SAVES INFO TO DATABASE



            }
        });

    }

    //Main method for creating na object to attach form to
    public static void openCreateManagerWindow()
    {
        CreateManagerAcctWindow createManagerAcctObj = new CreateManagerAcctWindow();
        createManagerAcctObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        createManagerAcctWindowFrame.setContentPane(new CreateManagerAcctWindow().createManagerAccountPanel);
        createManagerAcctWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        createManagerAcctWindowFrame.setTitle("Create Account");
        createManagerAcctWindowFrame.setSize(550, 500);
        createManagerAcctWindowFrame.setLocationRelativeTo(null);
        createManagerAcctWindowFrame.setVisible(true);
    }

}
