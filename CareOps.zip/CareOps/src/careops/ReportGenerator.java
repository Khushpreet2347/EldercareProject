package careops;

public class ReportGenerator {

	//variables

	private int month;
	private int year;

	//constructors

	//default
	public ReportGenerator() {
	}

	//parameterized 

	public ReportGenerator(int month, int year) {

	this.month = month;
	this.year = year; 
	}

	//method for report type

	public String generateReport(String type) {

	String report = "";

	if(type.equals("UserMedicationSummary")) {
	report = "Generating User Medication Summary report…";
	} else if(type.equals("HealthIrregularitiesSummary")) {
	report = "Generating Health Irregularities Summary report…";
	}else
	report = "Invalid report type.";
	

	return report;
	}

	
}
