package careops;

import java.util.Date;

public class Assignment {

	//variables

	private String HCN; //FK from Residents
	private String workID; //FK from Caregivers
	private String assignmentID; //PK
	private Date assignedDate;

	//constructors

	//defaults

	public Assignment() {
	}

	//parameterized
	public Assignment(String HCN, String workID, String assignmentID, Date assignedDate) {

	this.HCN = HCN;
	this.workID = workID;
	this.assignmentID = assignmentID;
	this.assignedDate = assignedDate;
	}

	
}
