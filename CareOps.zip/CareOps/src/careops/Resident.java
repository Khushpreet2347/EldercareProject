package careops;

public class Resident {

	//variables
	private String HCN; //PK
	private String fName;
	private String lName;
	private String dateOfBirth;
	private String email;
	private String phoneNo;
	private String profileImage; //image path
	private String eContactFName;
	private String eContactPhoneNo;

	//constructors

	//default
	Resident() {
	}

	//parameterized

	public Resident(String HCN, String fName, String lName, String dateOfBirth, String email, String phoneNo, String profileImage, String eContactFName, String eContactPhoneNo) {

	this.HCN = HCN;
	this.fName = fName;
	this.lName = lName;
	this.dateOfBirth = dateOfBirth;
	this.email = email;
	this.phoneNo = phoneNo;
	this.profileImage = profileImage;
	this.eContactFName = eContactFName;
	this.eContactPhoneNo = eContactPhoneNo;
	}

	
}
