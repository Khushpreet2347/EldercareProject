package careops;

public class TrendAnalyzer {

	//variables

	private double declineThreshold;
	private int windowDays;

	//constructors

	//default
	public TrendAnalyzer() {
	}

	//parameterized
	public TrendAnalyzer(double declineThreshold, int windowDays) {

	this.declineThreshold = declineThreshold;
	this.windowDays = windowDays;
	}

	
}
