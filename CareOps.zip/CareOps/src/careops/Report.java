package careops;

import java.util.Date;

public class Report {
	
	//variables

	private int reportID; //PK
	private String type; // User Medication Summary or Health Irregularities Summary
	private Date generatedAt;
	private String content;

	//constructors

	//default
	public Report() {
	}

	//parameterized
	public Report(int reportID, String type, Date generatedAt, String content) {

	this.reportID = reportID;
	this.type = type;
	this.generatedAt = generatedAt;
	this.content = content;
	}


}
