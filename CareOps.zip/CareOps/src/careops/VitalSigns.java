package careops;

public class VitalSigns {
	
	// variables
	private int recordID; // PK, FK from HealthRecord
	private int bloodPressure;
	private int bloodSugar;
	private double temperature;
	private int heartRate;

	//constructors

	//default

	public VitalSigns() {
	}

	//parameterized
	public VitalSigns(int recordID, int bloodPressure, int bloodSugar, double temperature, int heartRate) {

	this.recordID = recordID;
	this.bloodPressure = bloodPressure;
	this.bloodSugar = bloodSugar;
	this.temperature = temperature;
	this.heartRate = heartRate; 
	}


}
