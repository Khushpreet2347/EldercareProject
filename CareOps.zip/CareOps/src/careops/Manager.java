package careops;

public class Manager {

	//variables
	private String workID; //PK
	private String fName;
	private String lName;
	private String email;
	private String phoneNo;
	private String passwordHash;

	//constructors

	//default
	public Manager() {}


	//parameterized
	public Manager(String workID, String fName, String lName, String email, String phoneNo, String passwordHash) {

	this.workID = workID;
	this.fName = fName;
	this.lName = lName;
	this.email = email;
	this.phoneNo = phoneNo;
	this.passwordHash = passwordHash;
	}

	
}
