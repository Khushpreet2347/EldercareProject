package careops;

public class Caregiver {

	// variables
	private String workID; //PK
	private String fName;
	private String lName;
	private String email;
	private String phoneNo;

	//constructors

	//default
	public Caregiver() {
	}

	//parameterized
	public Caregiver(String workID, String fName, String lName, String email, String phoneNo) {
		
	this.workID = workID;
	this.fName = fName;
	this.lName = lName;
	this.email = email;
	this.phoneNo = phoneNo;
	}
	
}
