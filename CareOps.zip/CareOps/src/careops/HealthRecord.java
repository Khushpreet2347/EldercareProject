package careops;

public class HealthRecord {
	
	//variables

	private String HCN; // FK from Residents
	private int recordID; // PK
	private String entryDate;
	private String entryTime;
	private String note;
	//constructors

	//default
	public HealthRecord() {
	}

	//parameterized

	public HealthRecord(String HCN, int recordID, String entryDate, String entryTime, String note) {

	this.HCN = HCN;
	this.recordID = recordID;
	this.entryDate = entryDate;
	this.entryTime = entryTime;
	this.note = note;
	}


}

