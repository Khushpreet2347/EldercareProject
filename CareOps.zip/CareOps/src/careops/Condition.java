package careops;

public class Condition {

	//variables

	private int recordID; // FK from HealthRecord
	private int mood;
	private String painLevel;
	private int sleepQuality;

	//constructors

	//default
	public Condition() {
	}

	//parameterized
	public Condition(int recordID, int mood, String painLevel, int sleepQuality) {

	this.recordID = recordID;
	this.mood = mood;
	this.painLevel = painLevel;
	this.sleepQuality = sleepQuality;
	}
	
}
