package Connector;
import java.sql.*;

public class SQLConnection
{
    //public static void main(String[] args)
    public static Connection getConnection()
    {
        String url = "jdbc:mysql://localhost:3306/CareOps";
        String user = "root";
        String password = "root";

        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(url, user, password);
            return con;
        }
        catch (SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
            return null;
        }
    }
}
