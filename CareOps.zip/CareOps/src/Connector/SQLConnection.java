package Connector;

import java.sql.*;

public class SQLConnection
{

    //public static void main(String[] args)
    public static Connection getConnection()
    {

        String url = "jdbc:mysql://localhost:3306/CareOps";
        String user = "root";
        String password = "root";

        try
        {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(url, user, password);
            //System.out.println("Connected to CareOps Database");

            /*
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM ClassPackage.Manager");

            while(rs.next())
            {

                String id = rs.getString("workID");
                String name = rs.getString("fName");
                String email = rs.getString("email");
                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);

            }

            rs.close();
            stmt.close();*/
            //con.close();

            return con;

        }
        catch (SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
            return null;
        }

    }

}
