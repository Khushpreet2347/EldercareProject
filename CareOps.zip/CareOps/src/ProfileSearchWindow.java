import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProfileSearchWindow
{

    private JLabel titleLabel;
    private JRadioButton residentRdButton;
    private JRadioButton managerRdButton;
    private JRadioButton caregiverRdButton;
    private JTextField numberTextField;
    private JTextField nameTextField;
    private JButton searchButton;
    private JButton clearButton;
    private JList searchResultsList;
    private JSeparator searchSeparator;
    private JLabel numberLabel;
    private JLabel nameLabel;
    private JPanel profileSearchPanel;

    //Declare JFrame
    JFrame profileSearchWindowFrame = new JFrame();

    //Class holding methods for JFrame
    public ProfileSearchWindow()
    {

        //Set default radio button
        residentRdButton.setSelected(true);

        //Change number label based on profile type
        if(residentRdButton.isSelected())
        {
            numberLabel.setText("Work ID");
        }

        if(caregiverRdButton.isSelected())
        {
            numberLabel.setText("HCN");
        }

        if(managerRdButton.isSelected())
        {
            numberLabel.setText("Work ID");
        }

        //Action Listener to clear all text fields
        clearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                nameTextField.setText("");
                numberTextField.setText("");
            }
        });

        //Action Listener for the Search button. It uses the input to search SQL tables and displays in JList
        searchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });






    }

    //Method for creating an object to attach form to
    public static void openProfileSearchWindow()
    {
        ProfileSearchWindow profileSearchObj = new ProfileSearchWindow();
        profileSearchObj.callForm();
    }

    //Form structure to attach an object
    public void callForm()
    {
        profileSearchWindowFrame.setContentPane(new ProfileSearchWindow().profileSearchPanel);
        profileSearchWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        profileSearchWindowFrame.setTitle("Profile Search");
        profileSearchWindowFrame.setSize(300, 550);
        profileSearchWindowFrame.setLocationRelativeTo(null);
        profileSearchWindowFrame.setVisible(true);
    }

}
