import java.sql.*;

public class SQLConnection
{

    public static void main(String[] args)
    {

        String url = "jdbc:mysql://localhost:3306/CareOpsDatabase";
        //String user = //USERNAME
        //String password = //PASSWORD

        try
        {

            Class.forName("com.mysql.cj.jdbc.Driver");

            //Connection con = DriverManager.getConnection(url, user, password);
            Connection con = DriverManager.getConnection(url);
            System.out.println("Connected to CareOps Database");

            Statement statement = con.createStatement();

            ResultSet rs = statement.executeQuery("SELECT * FROM users");

            while(rs.next())
            {

                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);

            }

            rs.close();
            statement.close();
            con.close();

        }
        catch (SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }

    }

}
