package ClassPackage;

public class Manager
{

	//Variables
	private String workID; //PK
	private String fName;
	private String lName;
	private String email;
	private String phoneNo;
	private String passwordHash;

	//Constructors
	public Manager()
	{
		workID = "";
		fName = "";
		lName = "";
		email = "";
		phoneNo = "";
		passwordHash = "";
	}

	public Manager(String workID, String fName, String lName, String email, String phoneNo, String passwordHash)
	{
		this.workID = workID;
		this.fName = fName;
		this.lName = lName;
		this.email = email;
		this.phoneNo = phoneNo;
		this.passwordHash = passwordHash;
	}

	//Getters & Setters
	public String getWorkID() {
		return workID;
	}

	public void setWorkID(String workID) {
		this.workID = workID;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Manager{" +
				"workID='" + workID + '\'' +
				", fName='" + fName + '\'' +
				", lName='" + lName + '\'' +
				", email='" + email + '\'' +
				", phoneNo='" + phoneNo + '\'' +
				", passwordHash='" + passwordHash + '\'' +
				'}';
	}

}
