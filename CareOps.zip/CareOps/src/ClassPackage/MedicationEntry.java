package ClassPackage;

import java.time.Duration;
import java.time.LocalTime;


public class MedicationEntry
{
	
	//Variables
	private int recordID; //FK from ClassPackage.HealthRecord
	private int medEntryID; //PK
	private String mName; //name of medication
	private double dose;
	private String status; //given, late, missed
	private String note;
	private LocalTime time; //actual time admin by the caregiver

	//Constructors
	public MedicationEntry()
	{
		recordID = 0;
		medEntryID = 0;
		mName = "";
		dose = 0.0;
		status = "";
		note = "";
		time = null;
	}

	public MedicationEntry(int recordID, int medEntryID, String mName, double dose, String status, String note, LocalTime time)
	{
		this.recordID = recordID;
		this.medEntryID = medEntryID;
		this.mName = mName;
		this.dose = dose;
		this.status = status;
		this.note = note;
		this.time = time;
	}

	//Getters & Setters
	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public int getMedEntryID() {
		return medEntryID;
	}

	public void setMedEntryID(int medEntryID) {
		this.medEntryID = medEntryID;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public double getDose() {
		return dose;
	}

	public void setDose(double dose) {
		this.dose = dose;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	//To String method
	@Override
	public String toString()
	{
		return "MedicationEntry{" +
				"recordID=" + recordID +
				", medEntryID=" + medEntryID +
				", mName='" + mName + '\'' +
				", dose=" + dose +
				", status='" + status + '\'' +
				", note='" + note + '\'' +
				", time=" + time +
				'}';
	}

	//Method to update med status
	public void updateStatus(LocalTime expectedTime)
	{
		long minutes = Duration.between(expectedTime, time).toMinutes();

		if (minutes <= 60)
		{
			status = "Given";
		} else if (minutes <= 120) {
			status = "Late";
		} else {
			status = "Missed";
		}
	}

}
