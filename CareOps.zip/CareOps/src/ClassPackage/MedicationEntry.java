package ClassPackage;

import java.sql.Time;


public class MedicationEntry
{
	
	//Variables
	private int medEntryID; //PK
	private int recordID; //FK from ClassPackage.HealthRecord
	private String mName; //name of medication
	private double dose;
	private Time administeredTime;
	private String status; //given, late, missed
	private String note;

	//Constructors
	public MedicationEntry()
	{
		medEntryID = 0;
		recordID = 0;
		mName = "";
		dose = 0.0;
		administeredTime = null;
		status = "";
		note = "";
	}

	public MedicationEntry(int medEntryID, int recordID, String mName, double dose, Time administeredTime, String status, String note)
	{
		this.medEntryID = medEntryID;
		this.recordID = recordID;
		this.mName = mName;
		this.dose = dose;
		this.administeredTime = administeredTime;
		this.status = status;
		this.note = note;
	}

	//Getters & Setters
	public int getMedEntryID() {
		return medEntryID;
	}

	public void setMedEntryID(int medEntryID) {
		this.medEntryID = medEntryID;
	}

	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public double getDose() {
		return dose;
	}

	public void setDose(double dose) {
		this.dose = dose;
	}

	public Time getAdministeredTime() {
		return administeredTime;
	}

	public void setAdministeredTime(Time administeredTime) {
		this.administeredTime = administeredTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	//To String method
	@Override
	public String toString()
	{
		/*return "MedicationEntry{" +
				"medEntryID=" + medEntryID +
				", recordID=" + recordID +
				", mName='" + mName + '\'' +
				", dose=" + dose +
				", administeredTime=" + administeredTime +
				", status='" + status + '\'' +
				", note='" + note + '\'' +
				'}';
		*/

		return mName + " | " + dose + " | " + administeredTime + " | " + status;

	}

}
