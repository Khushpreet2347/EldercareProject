package ClassPackage;

import java.sql.Date;

public class HealthRecord
{
	
	//Variables
	private int recordID; // PK
	private String HCN; // FK from Residents
	private String fName;
	private String lName;
	private String entryDate;
	private String entryTime;
	private String note;
	private Date createdAt;

	//Constructors
	public HealthRecord()
	{
		recordID = 0;
		HCN = "";
		fName = "";
		lName = "";
		entryDate = "";
		entryTime = "";
		note = "";
		createdAt = null;
	}

	public HealthRecord(int recordID, String HCN, String fName, String lName, String entryDate, String entryTime, String note, Date createdAt)
	{
		this.recordID = recordID;
		this.HCN = HCN;
		this.fName = fName;
		this.lName = lName;
		this.entryDate = entryDate;
		this.entryTime = entryTime;
		this.note = note;
		this.createdAt = createdAt;
	}

	//Getters & Setters
	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public String getHCN() {
		return HCN;
	}

	public void setHCN(String HCN) {
		this.HCN = HCN;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Date getCreatedAt() { return createdAt; }

	public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

	//To String method
	@Override
	public String toString()
	{
		return "HealthRecord{" +
				"recordID=" + recordID +
				", HCN='" + HCN + '\'' +
				", fName='" + fName + '\'' +
				", lName='" + lName + '\'' +
				", entryDate='" + entryDate + '\'' +
				", entryTime='" + entryTime + '\'' +
				", note='" + note + '\'' +
				", createdAt=" + createdAt +
				'}';
	}

}

