package ClassPackage;

public class HealthRecord
{
	
	//Variables
	private String HCN; // FK from Residents
	private int recordID; // PK
	private String entryDate;
	private String entryTime;
	private String note;

	//Constructors
	public HealthRecord()
	{
		HCN = "";
		recordID = 0;
		entryDate = "";
		entryTime = "";
		note = "";
	}

	public HealthRecord(String HCN, int recordID, String entryDate, String entryTime, String note)
	{
		this.HCN = HCN;
		this.recordID = recordID;
		this.entryDate = entryDate;
		this.entryTime = entryTime;
		this.note = note;
	}

	//Getters & Setters
	public String getHCN() {
		return HCN;
	}

	public void setHCN(String HCN) {
		this.HCN = HCN;
	}

	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	//To String method
	@Override
	public String toString()
	{
		return "HealthRecord{" +
				"HCN='" + HCN + '\'' +
				", recordID=" + recordID +
				", entryDate='" + entryDate + '\'' +
				", entryTime='" + entryTime + '\'' +
				", note='" + note + '\'' +
				'}';
	}

}

