package ClassPackage;

public class ReportGenerator
{

	//Variables
	private int month;
	private int year;

	//Constructors
	public ReportGenerator()
	{
		month = 0;
		year = 0;
	}

	public ReportGenerator(int month, int year)
	{
		this.month = month;
		this.year = year;
	}

	//Getters & Setters
	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	//To String method
	@Override
	public String toString()
	{
		return "ReportGenerator{" +
				"month=" + month +
				", year=" + year +
				'}';
	}

	//Method for report type
	public String generateReport(String type)
	{
		String report = "";

		if (type.equals("UserMedicationSummary"))
		{
			report = "Generating User Medication Summary report…";
		} else if (type.equals("HealthIrregularitiesSummary"))
		{
			report = "Generating Health Irregularities Summary report…";
		} else
		{
			report = "Invalid report type.";
		}

		return report;

	}

}
