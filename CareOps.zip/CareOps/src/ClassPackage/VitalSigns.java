package ClassPackage;

public class VitalSigns
{
	
	//Variables
	private int recordID; // PK, FK from ClassPackage.HealthRecord
	private int bloodPressure;
	private int bloodSugar;
	private double temperature;
	private int heartRate;

	//Constructors
	public VitalSigns()
	{
		recordID = 0;
		bloodPressure = 0;
		bloodSugar = 0;
		temperature = 0.0;
		heartRate = 0;
	}

	public VitalSigns(int recordID, int bloodPressure, int bloodSugar, double temperature, int heartRate)
	{
		this.recordID = recordID;
		this.bloodPressure = bloodPressure;
		this.bloodSugar = bloodSugar;
		this.temperature = temperature;
		this.heartRate = heartRate;
	}

	//Getters & Setters
	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public int getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(int bloodPressure) {
		this.bloodPressure = bloodPressure;
	}

	public int getBloodSugar() {
		return bloodSugar;
	}

	public void setBloodSugar(int bloodSugar) {
		this.bloodSugar = bloodSugar;
	}

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public int getHeartRate() {
		return heartRate;
	}

	public void setHeartRate(int heartRate) {
		this.heartRate = heartRate;
	}

	//To String method
	@Override
	public String toString()
	{
		return "VitalSigns{" +
				"recordID=" + recordID +
				", bloodPressure=" + bloodPressure +
				", bloodSugar=" + bloodSugar +
				", temperature=" + temperature +
				", heartRate=" + heartRate +
				'}';
	}

}
