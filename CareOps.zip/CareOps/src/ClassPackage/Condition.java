package ClassPackage;

public class Condition
{

	//Variables
	private int recordID; // FK from ClassPackage.HealthRecord
	private int mood;
	private String painLevel;
	private int sleepQuality;

	//Constructors
	public Condition()
	{
		recordID = 0;
		mood = 0;
		painLevel = "";
		sleepQuality = 0;
	}

	public Condition(int recordID, int mood, String painLevel, int sleepQuality)
	{
		this.recordID = recordID;
		this.mood = mood;
		this.painLevel = painLevel;
		this.sleepQuality = sleepQuality;
	}

	//Getters & Setters
	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public int getMood() {
		return mood;
	}

	public void setMood(int mood) {
		this.mood = mood;
	}

	public String getPainLevel() {
		return painLevel;
	}

	public void setPainLevel(String painLevel) {
		this.painLevel = painLevel;
	}

	public int getSleepQuality() {
		return sleepQuality;
	}

	public void setSleepQuality(int sleepQuality) {
		this.sleepQuality = sleepQuality;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Condition{" +
				"recordID=" + recordID +
				", mood=" + mood +
				", painLevel='" + painLevel + '\'' +
				", sleepQuality=" + sleepQuality +
				'}';
	}

}
