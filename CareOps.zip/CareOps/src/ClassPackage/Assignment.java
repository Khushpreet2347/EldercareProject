package ClassPackage;

import java.util.Date;

public class Assignment
{

	//Variables
	private String HCN; //FK from Residents
	private String workID; //FK from Caregivers
	private String assignmentID; //PK
	private Date assignedDate;

	//Constructors
	public Assignment()
	{
		HCN = "";
		workID = "";
		assignmentID = "";
		assignedDate = null;
	}

	public Assignment(String HCN, String workID, String assignmentID, Date assignedDate)
	{
		this.HCN = HCN;
		this.workID = workID;
		this.assignmentID = assignmentID;
		this.assignedDate = assignedDate;
	}

	//Getters & Setters
	public String getHCN() {
		return HCN;
	}

	public void setHCN(String HCN) {
		this.HCN = HCN;
	}

	public String getWorkID() {
		return workID;
	}

	public void setWorkID(String workID) {
		this.workID = workID;
	}

	public String getAssignmentID() {
		return assignmentID;
	}

	public void setAssignmentID(String assignmentID) {
		this.assignmentID = assignmentID;
	}

	public Date getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(Date assignedDate) {
		this.assignedDate = assignedDate;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Assignment{" +
				"HCN='" + HCN + '\'' +
				", workID='" + workID + '\'' +
				", assignmentID='" + assignmentID + '\'' +
				", assignedDate=" + assignedDate +
				'}';
	}

}
