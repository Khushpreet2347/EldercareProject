package ClassPackage;

import java.util.Date;

public class Assignment
{

	//Variables
	private String assignmentID; //PK
	private String HCN; //FK from Residents
	private String workID; //FK from Caregivers
	private Date assignedDate;

	//Constructors
	public Assignment()
	{
		assignmentID = "";
		HCN = "";
		workID = "";
		assignedDate = null;
	}

	public Assignment(String assignmentID, String HCN, String workID, Date assignedDate)
	{
		this.assignmentID = assignmentID;
		this.HCN = HCN;
		this.workID = workID;
		this.assignedDate = assignedDate;
	}

	//Getters & Setters
	public String getAssignmentID() {
		return assignmentID;
	}

	public void setAssignmentID(String assignmentID) {
		this.assignmentID = assignmentID;
	}

	public String getHCN() {
		return HCN;
	}

	public void setHCN(String HCN) {
		this.HCN = HCN;
	}

	public String getWorkID() {
		return workID;
	}

	public void setWorkID(String workID) {
		this.workID = workID;
	}

	public Date getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(Date assignedDate) {
		this.assignedDate = assignedDate;
	}

	//To String method
	@Override
	public String toString() {
		return "Assignment{" +
				"assignmentID='" + assignmentID + '\'' +
				", HCN='" + HCN + '\'' +
				", workID='" + workID + '\'' +
				", assignedDate=" + assignedDate +
				'}';
	}

}
