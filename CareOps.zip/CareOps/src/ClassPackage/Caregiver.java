package ClassPackage;

public class Caregiver
{

	//Variables
	private String workID; //PK
	private String fName;
	private String lName;
	private String email;
	private String phoneNo;

	//Constructors
	public Caregiver()
	{
		workID = "";
		fName = "";
		lName = "";
		email = "";
		phoneNo = "";
	}

	public Caregiver(String workID, String fName, String lName, String email, String phoneNo)
	{
		this.workID = workID;
		this.fName = fName;
		this.lName = lName;
		this.email = email;
		this.phoneNo = phoneNo;
	}

	//Getters & Setters
	public String getWorkID() {
		return workID;
	}

	public void setWorkID(String workID) {
		this.workID = workID;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Caregiver{" +
				"workID='" + workID + '\'' +
				", fName='" + fName + '\'' +
				", lName='" + lName + '\'' +
				", email='" + email + '\'' +
				", phoneNo='" + phoneNo + '\'' +
				'}';
	}

}
