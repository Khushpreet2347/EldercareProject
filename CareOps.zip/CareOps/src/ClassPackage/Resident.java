package ClassPackage;

public class Resident
{

	//Variables
	private String HCN; //PK
	private String fName;
	private String lName;
	private String dateOfBirth;
	private String email;
	private String phoneNo;
	private String profileImage; //image path
	private String eContactFName;
	private String eContactPhoneNo;

	//Constructors
    public Resident()
	{
		HCN = "";
		fName = "";
		lName = "";
		dateOfBirth = "";
		email = "";
		phoneNo = "";
		profileImage = "";
		eContactFName = "";
		eContactPhoneNo = "";
	}

	public Resident(String HCN, String fName, String lName, String dateOfBirth, String email, String phoneNo, String profileImage, String eContactFName, String eContactPhoneNo)
	{
		this.HCN = HCN;
		this.fName = fName;
		this.lName = lName;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.phoneNo = phoneNo;
		this.profileImage = profileImage;
		this.eContactFName = eContactFName;
		this.eContactPhoneNo = eContactPhoneNo;
	}

	//Getters & Setters
	public String getHCN() {
		return HCN;
	}

	public void setHCN(String HCN) {
		this.HCN = HCN;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public String geteContactFName() {
		return eContactFName;
	}

	public void seteContactFName(String eContactFName) {
		this.eContactFName = eContactFName;
	}

	public String geteContactPhoneNo() {
		return eContactPhoneNo;
	}

	public void seteContactPhoneNo(String eContactPhoneNo) {
		this.eContactPhoneNo = eContactPhoneNo;
	}

	//To String Method
	@Override
	public String toString()
	{
		return "Resident{" +
				"HCN='" + HCN + '\'' +
				", fName='" + fName + '\'' +
				", lName='" + lName + '\'' +
				", dateOfBirth='" + dateOfBirth + '\'' +
				", email='" + email + '\'' +
				", phoneNo='" + phoneNo + '\'' +
				", profileImage='" + profileImage + '\'' +
				", eContactFName='" + eContactFName + '\'' +
				", eContactPhoneNo='" + eContactPhoneNo + '\'' +
				'}';
	}

}
