package ClassPackage;

import java.util.Date;

public class Report
{
	
	//Variables
	private int reportID; //PK
	private String type; // User Medication Summary or Health Irregularities Summary
	private Date generatedAt;
	private String content;

	//Constructors
	public Report()
	{
		reportID = 0;
		type = "";
		generatedAt = null;
		content = "";
	}

	public Report(int reportID, String type, Date generatedAt, String content)
	{
		this.reportID = reportID;
		this.type = type;
		this.generatedAt = generatedAt;
		this.content = content;
	}

	//Getters & Setters
	public int getReportID() {
		return reportID;
	}

	public void setReportID(int reportID) {
		this.reportID = reportID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getGeneratedAt() {
		return generatedAt;
	}

	public void setGeneratedAt(Date generatedAt) {
		this.generatedAt = generatedAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Report{" +
				"reportID=" + reportID +
				", type='" + type + '\'' +
				", generatedAt=" + generatedAt +
				", content='" + content + '\'' +
				'}';
	}

}
