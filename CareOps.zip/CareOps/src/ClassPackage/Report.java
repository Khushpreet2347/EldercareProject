package ClassPackage;

import java.util.Date;

public class Report
{

	//Variables
	private int reportID; //PK
	private String type; // User Medication Summary or Health Irregularities Summary
	private int year;
	private int month;
	private String content;

	//Constructors
	public Report()
	{
		reportID = 0;
		type = "";
		year = 0;
		month = 0;
		content = "";
	}

	public Report(int reportID, String type, int year, int month, String content)
	{
		this.reportID = reportID;
		this.type = type;
		this.year = year;
		this.month = month;
		this.content = content;
	}

    //Getters & Setters
	public int getReportID() {
		return reportID;
	}

	public void setReportID(int reportID) {
		this.reportID = reportID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Report{" +
				"reportID=" + reportID +
				", type='" + type + '\'' +
				", year=" + year +
				", month=" + month +
				", content='" + content + '\'' +
				'}';
	}

}