package ClassPackage;

import java.sql.Time;
import java.util.Date;

public class Activity
{

    //Variables
    private int activityID; //PK
    private String title;
    private Date date;
    private Time time;
    private String description;
    private String participantNotes;
    private String status;

    //Constructors
    public Activity()
    {
        activityID = 0;
        title = "";
        date = null;
        time = null;
        description = "";
        participantNotes = "";
        status = "";
    }

    public Activity(int activityID, String title, Date date, Time time, String description, String participantNotes, String status)
    {
        this.activityID = activityID;
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
        this.participantNotes = participantNotes;
        this.status = status;
    }

    //Getters & Setters
    public int getActivityID() {
        return activityID;
    }

    public void setActivityID(int activityID) {
        this.activityID = activityID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getParticipantNotes() {
        return participantNotes;
    }

    public void setParticipantNotes(String participantNotes) {
        this.participantNotes = participantNotes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    //To String Method
    @Override
    public String toString()
    {
        return "Activity{" +
                "activityID=" + activityID +
                ", title='" + title + '\'' +
                ", date=" + date +
                ", time=" + time +
                ", description='" + description + '\'' +
                ", participantNotes='" + participantNotes + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

}
