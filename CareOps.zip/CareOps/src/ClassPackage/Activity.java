package ClassPackage;

import java.util.Date;

public class Activity
{

    //Variables
    private int activityID; //PK
    private String type; //Medication, alert, login...
    private String description;
    private Date timestamp;
    private String workID; //FK - caregivers or managers
    private String HCN; // FK from resident

    //Constructors
    public Activity()
    {
        activityID = 0;
        type = "";
        description = "";
        timestamp = null;
        workID = "";
        HCN = "";
    }

    public Activity(int activityID, String type, String description, Date timestamp, String workID, String HCN)
    {
        this.activityID = activityID;
        this.type = type;
        this.description = description;
        this.timestamp = timestamp;
        this.workID = workID;
        this.HCN = HCN;
    }

    //Getters & Setters
    public int getActivityID() {
        return activityID;
    }

    public void setActivityID(int activityID) {
        this.activityID = activityID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getWorkID() {
        return workID;
    }

    public void setWorkID(String workID) {
        this.workID = workID;
    }

    public String getHCN() {
        return HCN;
    }

    public void setHCN(String HCN) {
        this.HCN = HCN;
    }

    //To String method
    @Override
    public String toString()
    {
        return "Activity{" +
                "activityID=" + activityID +
                ", type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", timestamp=" + timestamp +
                ", workID='" + workID + '\'' +
                ", HCN='" + HCN + '\'' +
                '}';
    }

    //Method to log actions
    public void logActivity()
    {
        System.out.println("Activity type: " + type + ", for Resident (HCN: " + HCN + "), by Employee (work ID: " + workID + ") at " + timestamp + ".");

    }

}
