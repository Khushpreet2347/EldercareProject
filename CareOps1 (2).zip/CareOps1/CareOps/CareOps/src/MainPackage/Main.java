package MainPackage;
import java.sql.*;
import java.util.List;

import Connector.SQLConnection;

//TEST
import DAOPackage.CaregiverDAO;
import DAOPackage.ManagerDAO;
import GUIPackage.LogInWindow;
import GUIPackage.ManagerMenuWindow;

public class Main
{
    public static void main(String[] args)
    {
        //TEST LOG IN
        LogInWindow.openLoginWindow();

        //TEST CONNECTION
        /*
        try
        {
            Connection con = SQLConnection.getConnection();

            if(con == null)
            {
                System.out.println("Cannot connect to database");
                return;
            }

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            while(rs.next())
            {
                String id = rs.getString("workID");
                String name = rs.getString("fName");
                String email = rs.getString("email");

                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);
            }

            rs.close();
            stmt.close();
            con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        */


        //TEST
        /*ManagerDAO mDAO = new ManagerDAO();
        List<Manager> managers = mDAO.getAllManagers();

        //test
        for(Manager m : managers)
        {
            System.out.println(m);
        }

        System.out.println("\n");

        CaregiverDAO cDAO = new CaregiverDAO();
        List<Caregiver> caregivers = cDAO.getCaregivers();

        for(Caregiver c : caregivers)
        {
            System.out.println(c);
        }*/



        //TEST MAIN MENU
      //  ManagerMenuWindow.openMainMenuWindow();


    }
}
