package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.Manager;
import MainPackage.PasswordUtil;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ManagerDAO
{

    //Method that returns a list of Manager objects to access data from
    public List<Manager> getAllManagers()
    {

        //Declare a list of Manager objects
        List<Manager> managers = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            //Populate Manager objects
            while(rs.next())
            {
                Manager manager = new Manager
                    (
                        rs.getString("workID"),
                        rs.getString("fName"),
                        rs.getString("lName"),
                        rs.getString("email"),
                        rs.getString("phoneNo"),
                        rs.getString("passwordHash")
                    );

                //Add objects to List
                managers.add(manager);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return managers;

    }

    //Method that returns one manager object to access data from (BY WORK ID)
    public Manager getOneManagerViaID(String inputWorkID)
    {

        //Declare a Manager object
        Manager manager = null;

        //Connect to database
        try
        {
            
            Connection con = SQLConnection.getConnection();

            //Search by WorkID
            if(inputWorkID != null && !inputWorkID.trim().isEmpty())
            {
                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM Manager WHERE workID = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                //Set string to workID (? will be set to workID)
                stmt.setString(1, inputWorkID);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    manager = new Manager
                    (
                        rs.getString("workID"),
                        rs.getString("fName"),
                        rs.getString("lName"),
                        rs.getString("email"),
                        rs.getString("phoneNo"),
                        rs.getString("passwordHash")
                    );
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return manager object
                return manager;
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method that returns one manager object to access data from (BY NAME)
    public Manager getOneManagerViaName(String inputFullName)
    {

        //Declare a Manager object
        Manager manager = null;

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if(nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                    return null;
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM Manager WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                //Set string to names (changes ? in statement to names)
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    manager = new Manager
                            (
                                    rs.getString("workID"),
                                    rs.getString("fName"),
                                    rs.getString("lName"),
                                    rs.getString("email"),
                                    rs.getString("phoneNo"),
                                    rs.getString("passwordHash")
                            );
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return object
                return manager;

            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }
    
    //Method to create a manager in the database
    public void createManager(String inputWorkID, String inputFName, String inputLName, String inputEmail,
                              String inputPhoneNo, String inputPassword)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO Manager VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputWorkID);
            stmt.setString(2, inputFName);
            stmt.setString(3, inputLName);
            stmt.setString(4, inputEmail);
            stmt.setString(5, inputPhoneNo);

            //hash password
            String hashedPassword = PasswordUtil.hashPassword(inputPassword);
            stmt.setString(6, hashedPassword);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify a manager in the database
    public void modifyManager(String inputFullName, String inputWorkID, String inputFName, String inputLName, String inputEmail,
                              String inputPhoneNo, String inputPassword)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "UPDATE Manager SET workID = ?, fName = ?, lName = ?, email = ?, phoneNo = ?, passwordHash = ? WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                //Set string to names (changes ? in statement to names)
                stmt.setString(1, inputWorkID);
                stmt.setString(2, inputFName);
                stmt.setString(3, inputLName);
                stmt.setString(4, inputEmail);
                stmt.setString(5, inputPhoneNo);

                //hash password
                String hashedPassword = PasswordUtil.hashPassword(inputPassword);
                stmt.setString(6, hashedPassword);

                stmt.setString(7, fName);
                stmt.setString(8, lName);

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();

            }

            //Close connection
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete a manager in the database
    public void deleteManager(String inputFullName)
    {
        
        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if(nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "DELETE FROM Manager WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();

            }

            //Close connection
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
    }

}
