package DAOPackage;

import java.sql.*;
import java.util.*;

import Connector.SQLConnection;
import ClassPackage.MedicationEntry;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class MedicationEntryDAO
{
    //Method that returns a list of Medication objects to access data from
    public List<MedicationEntry> getAllMedicationEntry()
    {

        //Declare a list of Medication Entry objects
        List<MedicationEntry> medicationEntries = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MedicationEntry");

            //Populate Manager objects
            while(rs.next())
            {
                MedicationEntry medicationEntry = new MedicationEntry
                    (
                        rs.getInt("medEntryID"),
                        rs.getInt("recordID"),
                        rs.getString("mName"),
                        rs.getDouble("dose"),
                        rs.getTime("administeredTime"),
                        rs.getString("status"),
                        rs.getString("note")
                    );

                //Add objects to List
                medicationEntries.add(medicationEntry);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return medicationEntries;

    }

    //Method that returns one medication object to access data from
    public MedicationEntry getOneMedicationEntry(int recordID)
    {

        //Declare a Medication Entry object
        MedicationEntry medicationEntry = new MedicationEntry();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input for query
            String query = "SELECT * FROM MedicationEntry WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, recordID);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while(rs.next())
            {
                medicationEntry = new MedicationEntry
                (
                    rs.getInt("medEntryID"),
                    rs.getInt("recordID"),
                    rs.getString("mName"),
                    rs.getDouble("dose"),
                    rs.getTime("administeredTime"),
                    rs.getString("status"),
                    rs.getString("note")
                );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return medicationEntry object
            return medicationEntry;

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method to create a medication entry in the database
    public void createAssignment(int inputMedEntryID, int inputRecordID, String inputMName,
                                 double inputDose, Time inputAdministedTime, String inputStatus, String inputNote)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO MedicationEntry VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputMedEntryID);
            stmt.setInt(2, inputRecordID);
            stmt.setString(3, inputMName);
            stmt.setDouble(4, inputDose);
            stmt.setTime(5, inputAdministedTime);
            stmt.setString(6, inputStatus);
            stmt.setString(7, inputNote);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify a medication entry in the database
    public void modifyMedicationEntry(int inputRecordID, String inputMName,
                                      double inputDose, Time inputAdministedTime, String inputStatus, String inputNote)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by recordID
            //Use a prepared statement in order to use user input in the query
            String query = "UPDATE MedicationEntry SET mName = ?, dose = ?, administeredTime = ?, status = ?, note = ? WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputMName);
            stmt.setDouble(2, inputDose);
            stmt.setTime(3, inputAdministedTime);
            stmt.setString(4, inputStatus);
            stmt.setString(5, inputNote);
            stmt.setInt(6, inputRecordID);

            //Execute query
            stmt.executeUpdate();

            //Closer resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete a medication entry from the database
    public void deleteMedicationEntry(String medEntryID)
    {

        //Connecto to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by medID
            //Use a prepared statement in order to use user input in the query
            String query = "DELETE FROM MedicationEntry WHERE medEntryID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, medEntryID);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

}