package DAOPackage;

import java.sql.*;
import java.util.*;
import java.util.Date;

import Connector.SQLConnection;
import ClassPackage.Activity;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ActivityDAO
{

    //Method that returns a list of Activity objects to access data from
    public List<Activity> getActivities()
    {

        //Declare a list of Manager objects
        List<Activity> activities = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Activity");

            //Populate Activity objects
            while(rs.next())
            {
                Activity activity = new Activity
                    (
                        rs.getInt("activityID"),
                        rs.getString("title"),
                        rs.getDate("date"),
                        rs.getTime("time"),
                        rs.getString("description"),
                            rs.getString("participantNotes"),
                            rs.getString("status")
                    );

                //Add objects to List
                activities.add(activity);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Activity objects
        return activities;

    }
    //Method that returns one activity object to access data from
    public Activity getOneActivity(int inputActivityID, String inputTitle, Date inputDate, Time inputTime, String inputDescription, String inputParticipantNotes, String inputStatus)
    {

        //Declare an Activity object
        Activity activity = new Activity();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by WorkID
            if(inputWorkID != null && !inputWorkID.trim().isEmpty())
            {
                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM Activity WHERE workID = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                //Set string to workID (? will be set to workID)
                stmt.setString(1, inputWorkID);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    activity = new Activity
                            (
                                    rs.getInt("activityID"),
                                    rs.getString("title"),
                                    rs.getDate("date"),
                                    rs.getTime("time"),
                                    rs.getString("description"),
                                    rs.getString("participantNotes"),
                                    rs.getString("status")
                            );
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return activity object
                return activity;
            }

            //Search by full name
            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if(nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                    return null;
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "SELECT * FROM Activity WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                //Set string to names (changes ? in statement to names)
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Save attributes to object
                while (rs.next())
                {
                    activity = new Activity
                            (
                                    rs.getInt("activityID"),
                                    rs.getString("title"),
                                    rs.getDate("date"),
                                    rs.getTime("time"),
                                    rs.getString("description"),
                                    rs.getString("participantNotes"),
                                    rs.getString("status")
                            );
                }

                //Close resources
                rs.close();
                stmt.close();
                con.close();

                //Return object
                return activity;

            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method to create an activity in the database
    public void createActivity(int inputActivityID, String inputTitle, Date inputDate, Time inputTime, String inputDescription, String inputParticipantNotes, String inputStatus)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO Activity VALUES ('?', '?', '?', '?', '?', '?')";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, "activityID");
            stmt.setString(2, "title");
            stmt.setDate(3, "date"),
                    stmt.setTime(4, "time"),
            stmt.setString(5, "description");
            stmt.setString(6, "participantNotes");
            stmt.setString(7, "status");

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify an activity in the database
    public void modifyActivity(int inputActivityID, String inputTitle, Date inputDate, Time inputTime, String inputDescription, String inputParticipantNotes, String inputStatus)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "UPDATE Activity SET workID = ? AND fName = ? AND lName = ? AND email = ? AND phoneNo = ? AND passwordHash = ? WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                //Set string to names (changes ? in statement to names)
                stmt.setString(1, inputActivityID);
                stmt.setString(2, inputTitle);
                stmt.setString(3, inputDate);
                stmt.setString(4, inputTime);
                stmt.setString(5, inputDescription);
                stmt.setString(6, inputParticipantNotes);
                stmt.setString(7, inputStatus);

                //Execute query
                ResultSet rs = stmt.executeQuery();

                //Close resources
                rs.close();
                stmt.close();

            }

            //Close connection
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete an activity in the database
    public void deleteActivity(String inputFullName)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by full name
            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                //Split the full name into a first and last name
                String[] nameSplit = inputFullName.trim().split(" ");

                //Check if user entered a full name
                if(nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                }

                //Save split full name to separate variables
                String fName = nameSplit[0];
                String lName = nameSplit[1];

                //Use a prepared statement in order to use user input in the query
                String query = "DELETE FROM Activity WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();

            }

            //Close connection
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

}
