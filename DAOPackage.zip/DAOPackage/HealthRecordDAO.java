package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.HealthRecord;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class HealthRecordDAO
{

    //Method returns a list of Health Record objects to access data from
    public List<HealthRecord> getHealthRecord()
    {

        //Declare a list of Health Record objects
        List<HealthRecord> healthRecords = new ArrayList<>();

        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM HealthRecord");

            //Populate Health Record objects
            while(rs.next())
            {
                HealthRecord healthRecord = new HealthRecord
                    (
                        rs.getString("HCN"),
                        rs.getInt("recordID"),
                        rs.getString("entryDate"),
                        rs.getString("entryTime"),
                        rs.getString("note")
                    );

                //Add objects to List
                healthRecords.add(healthRecord);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Health Record objects
        return healthRecords;

    }

}

        //Method that returns one Health Record object to access data from
        public HealthRecord getOneHealthRecord(String inputHCN, int recordID, String entryDate, String entryTime, String note)
        {

            //Declare a Manager object
            HealthRecord healthRecord = new HealthRecord();

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by WorkID
                if(inputWorkID != null && !inputWorkID.trim().isEmpty())
                {
                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM HealthRecord WHERE workID = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to workID (? will be set to workID)
                    stmt.setString(1, inputWorkID);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        healthRecord = new HealthRecord()
                                (
                                        rs.getString("HCN"),
                                        rs.getInt("recordID"),
                                        rs.getString("entryDate"),
                                        rs.getString("entryTime"),
                                        rs.getString("note")
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return health record object
                    return healthRecord;
                }

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                        return null;
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM HealthRecord WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        healthRecord = new HealthRecord()
                                (
                                        rs.getString("HCN"),
                                        rs.getInt("recordID"),
                                        rs.getString("entryDate"),
                                        rs.getString("entryTime"),
                                        rs.getString("note")
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return object
                    return healthRecord;

                }

            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }

            //Return no results if user input does not match any database entries
            return null;

        }

        //Method to create a health record in the database
        public void createHealthRecord(String inputHCN, int recordID, String entryDate, String entryTime, String note)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Query for creating a new entry into the database
                String query = "INSERT INTO HealthRecord VALUES ('?', '?', '?', '?', '?', '?')";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, "HCN");
                stmt.setInt(2, "recordID");
                stmt.setString(3, "entryDate");
                stmt.setString(4, "entryTime");
                stmt.setString(4, "note");


                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

        //Method to modify a health record in the database
        public void modifyHealthRecord(String inputHCN, int recordID, String entryDate, String entryTime, String note)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if (nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "UPDATE HealthRecord SET workID = ? AND fName = ? AND lName = ? AND email = ? AND phoneNo = ? AND passwordHash = ? WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, inputHCN);
                    stmt.setInt(2, inputRecordID);
                    stmt.setString(3, inputEntryDate);
                    stmt.setString(4, inputEntryTime);
                    stmt.setString(5, inputNote);


                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Close resources
                    rs.close();
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Method to delete a health record in the database
        public void deleteHealthRecord(String inputHCN, int recordID, String entryDate, String entryTime, String note)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "DELETE FROM HealthRecord WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    stmt.executeUpdate();

                    //Close resources
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

}