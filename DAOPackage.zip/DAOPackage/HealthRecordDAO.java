package DAOPackage;

import java.sql.*;
import ClassPackage.HealthRecord;
import Connector.SQLConnection;
import java.util.ArrayList;
import java.util.List;

public class HealthRecordDAO
{

    //Get Health Records (filter by date or medication status)
    public List<HealthRecord> getAllHealthRecords(String inputDate, String inputMedStatus)
    {

        List<HealthRecord> healthRecords = new ArrayList<>();

        try
        {
            Connection con = SQLConnection.getConnection();

            //Base query
            String query =
                    "SELECT DISTINCT hr.* FROM HealthRecord hr ";

            boolean hasStatus = (inputMedStatus != null && !inputMedStatus.trim().isEmpty());

            if (hasStatus)
            {
                query += "JOIN MedicationEntry me ON hr.recordID = me.recordID ";
            }

            query += "WHERE 1=1 ";

            if (inputDate != null && !inputDate.trim().isEmpty())
            {
                query += "AND hr.entryDate = ? ";
            }

            if (hasStatus)
            {
                query += "AND me.status = ? ";
            }

            PreparedStatement stmt = con.prepareStatement(query);

            int index = 1;

            if (inputDate != null && !inputDate.trim().isEmpty())
            {
                stmt.setString(index++, inputDate);
            }

            if (hasStatus)
            {
                stmt.setString(index++, inputMedStatus);
            }

            ResultSet rs = stmt.executeQuery();

            while (rs.next())
            {
                HealthRecord healthRecord = new HealthRecord(
                        rs.getInt("recordID"),
                        rs.getString("HCN"),
                        rs.getDate("entryDate"),
                        rs.getTime("entryTime"),
                        rs.getString("note")
                );

                healthRecords.add(healthRecord);
            }

            rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return healthRecords;
    }


    //Get ONE Health Record
    public HealthRecord getOneHealthRecord(String inputRecordID)
    {

        HealthRecord healthRecord = null;

        try
        {
            Connection con = SQLConnection.getConnection();

            String query = "SELECT * FROM HealthRecord WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setInt(1, Integer.parseInt(inputRecordID));

            ResultSet rs = stmt.executeQuery();

            if (rs.next())
            {
                healthRecord = new HealthRecord(
                        rs.getInt("recordID"),
                        rs.getString("HCN"),
                        rs.getDate("entryDate"),
                        rs.getTime("entryTime"),
                        rs.getString("note")
                );
            }

            rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return healthRecord;
    }


    //Create Health Record
    public void createHealthRecord(String inputHCN, Date inputEntryDate,
                                   Time inputEntryTime, String inputNote)
    {

        try
        {
            Connection con = SQLConnection.getConnection();

            String query =
                    "INSERT INTO HealthRecord (HCN, entryDate, entryTime, note) " + "VALUES (?, ?, ?, ?)";

            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, inputHCN);
            stmt.setDate(2, inputEntryDate);
            stmt.setTime(3, inputEntryTime);
            stmt.setString(4, inputNote);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }


    //Modify Health Record
    public void modifyHealthRecord(int inputRecordID, String inputHCN,
                                   Date entryDate, Time entryTime, String inputNote)
    {

        try
        {
            Connection con = SQLConnection.getConnection();

            String query =
                    "UPDATE HealthRecord SET " + "HCN = ?, entryDate = ?, entryTime = ?, note = ? " + "WHERE recordID = ?";

            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, inputHCN);
            stmt.setDate(2, entryDate);
            stmt.setTime(3, entryTime);
            stmt.setString(4, inputNote);
            stmt.setInt(5, inputRecordID);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }


    //Delete Health Record
    public void deleteHealthRecord(int inputRecordID)
    {

        try
        {
            Connection con = SQLConnection.getConnection();

            String query = "DELETE FROM HealthRecord WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setInt(1, inputRecordID);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

}