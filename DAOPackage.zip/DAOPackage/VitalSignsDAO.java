package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.VitalSigns;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class VitalSignsDAO
{

    //Method that returns a list of Vital Sign objects to access data from
    public List<VitalSigns> getAllVitalSigns()
    {

        //Declare a list of Manager objects
        List<VitalSigns> vitalSigns = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM VitalSigns");

            //Populate Vital Sign objects
            while (rs.next())
            {
                VitalSigns vitalSign = new VitalSigns
                (
                    rs.getInt("recordID"),
                    rs.getInt("systolic"),
                    rs.getInt("diastolic"),
                    rs.getInt("bloodSugar"),
                    rs.getDouble("temperature"),
                    rs.getInt("heartRate")
                );

                //Add objects to List
                vitalSigns.add(vitalSign);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return vitalSigns;

    }

    //Method that returns one vital signs object to access data from
    public VitalSigns getOneVitalSigns(int recordID)
    {

        //Declare a vital signs object
        VitalSigns vitalSigns = new VitalSigns();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Search by RecordID
            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM VitalSigns WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, recordID);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while (rs.next())
            {
                vitalSigns = new VitalSigns
                (
                    rs.getInt("recordID"),
                    rs.getInt("systolic"),
                    rs.getInt("diastolic"),
                    rs.getInt("bloodSugar"),
                    rs.getDouble("temperature"),
                    rs.getInt("heartRate")
                );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return manager object
            return vitalSigns;

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        //Return no results if user input does not match any database entries
        return null;

    }

    //Method to create a vital signs in the database
    public void createVitalSigns(int inputRecordID, int inputSystolic, int inputDiastolic, int inputBloodSugar,
                                 double inputTemperature, int inputHeartRate)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Query for creating a new entry into the database
            String query = "INSERT INTO VitalSigns (recordID, systolic, diastolic, bloodSugar, temperature, heartRate) VALUES (?, ?, ?, ?, ?, ?)";            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputRecordID);
            stmt.setInt(2, inputSystolic);
            stmt.setInt(3, inputDiastolic);
            stmt.setInt(4, inputBloodSugar);
            stmt.setDouble(5, inputTemperature);
            stmt.setInt(6, inputHeartRate);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify a vital signs in the database
    public void modifyVitalSigns(int inputRecordID, int inputSystolic, int inputDiastolic, int inputBloodSugar,
                                 double inputTemperature, int inputHeartRate)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "UPDATE VitalSigns SET systolic = ?, diastolic = ?, bloodSugar = ?, temperature = ?, heartRate = ? WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, inputSystolic);
            stmt.setInt(2, inputDiastolic);
            stmt.setInt(3, inputBloodSugar);
            stmt.setDouble(4, inputTemperature);
            stmt.setInt(5, inputHeartRate);
            stmt.setInt(6, inputRecordID);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete a vital signs in the database
    public void deleteVitalSigns(int recordID)
    {

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();

            //Use a prepared statement in order to use user input in the query
            String query = "DELETE FROM VitalSigns WHERE recordID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, recordID);

            //Execute query
            stmt.executeUpdate();

            //Close resources
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }
}



