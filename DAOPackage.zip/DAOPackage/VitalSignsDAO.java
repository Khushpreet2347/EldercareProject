package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.VitalSigns;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class VitalSignsDAO
{

    //Method that returns a list of Vital Sign objects to access data from
    public List<VitalSigns> getVitalSigns()
    {

        //Declare a list of Manager objects
        List<VitalSigns> vitalSigns = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM VitalSigns");

            //Populate Vital Sign objects
            while(rs.next())
            {
                VitalSigns vitalSign = new VitalSigns
                        (
                                rs.getInt("recordID"),
                                rs.getInt("bloodPressure"),
                                rs.getInt("bloodSugar"),
                                rs.getDouble("temperature"),
                                rs.getInt("heartRate")
                        );

                //Add objects to List
                vitalSigns.add(vitalSign);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Manager objects
        return vitalSigns;

    }

}
        //Method that returns one vital signs object to access data from
        public VitalSigns getOneVitalSigns(int inputRecordID, int inputBloodPressure, int inputBloodSugar, double inputTemperature, int inputHeartRate)
        {

            //Declare a vital signs object
            VitalSigns vitalSigns = new VitalSigns();

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by WorkID
                if(inputWorkID != null && !inputWorkID.trim().isEmpty())
                {
                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM VitalSigns WHERE workID = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to workID (? will be set to workID)
                    stmt.setString(1, inputWorkID);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        vitalSigns = new VitalSigns
                                (
                                        rs.getInt("recordID"),
                                        rs.getInt("bloodPressure"),
                                        rs.getInt("bloodSugar"),
                                        rs.getDouble("temperature"),
                                        rs.getInt("heartRate"),
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return manager object
                    return vitalSigns;
                }

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                        return null;
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM VitalSigns WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        vitalSigns = new VitalSigns()
                                (
                                        rs.getInt("recordID"),
                                        rs.getInt("bloodPressure"),
                                        rs.getInt("bloodSugar"),
                                        rs.getDouble("temperature"),
                                        rs.getInt("heartRate"),
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return object
                    return vitalSigns;

                }

            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }

            //Return no results if user input does not match any database entries
            return null;

        }

        //Method to create a vital signs in the database
        public void createVitalSigns(int inputRecordID, int inputBloodPressure, int inputBloodSugar, double inputTemperature, int inputHeartRate)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Query for creating a new entry into the database
                String query = "INSERT INTO VitalSigns VALUES ('?', '?', '?', '?', '?', '?')";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setInt(1, "recordID");
                stmt.setInt(2, "bloodPressure");
                stmt.setInt(3, "bloodSugar");
                stmt.setDouble(4, "temperature");
                stmt.setInt(4, "heartRate");

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

        //Method to modify a vital signs in the database
        public void modifyVitalSigns(int inputRecordID, int inputBloodPressure, int inputBloodSugar, double inputTemperature, int inputHeartRate)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if (nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "UPDATE VitalSigns SET workID = ? AND fName = ? AND lName = ? AND email = ? AND phoneNo = ? AND passwordHash = ? WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setInt(1, inputRecordID);
                    stmt.setInt(2, inputBloodPressure);
                    stmt.setInt(3, inputBloodSugar);
                    stmt.setDouble(4, inputTemperature);
                    stmt.setInt(5, inputHeartRate);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Close resources
                    rs.close();
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Method to delete a vital signs in the database
        public void deleteVitalSigns(int inputRecordID, int inputBloodPressure, int inputBloodSugar, double inputTemperature, int inputHeartRate)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "DELETE FROM VitalSigns WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    stmt.executeUpdate();

                    //Close resources
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

}

