package DAOPackage;

import java.sql.*;
import java.util.*;
import java.util.Date;

import Connector.SQLConnection;
import ClassPackage.Assignment;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class AssignmentDAO
{
    //Method that returns a list of Assignment objects to access data from
    public List<Assignment> getAssignment()
    {

        //Declare a list of assignment objects
        List<Assignment> assignments = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Assignment");

            //Populate Assignment objects
            while(rs.next())
            {
                Assignment assignment = new Assignment
                    (
                    rs.getString("HCN"),
                    rs.getString("workID"),
                    rs.getString("assignmentID"),
                    rs.getDate("assignedDate")
                    );

                //Add objects to List
                assignments.add(assignment);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Assignment objects
        return assignments;

    }
}
        //Method that returns one assignment object to access data from
        public Assignment getOneAssignment(String inputAssignmentID, String inputHCN, String inputWorkID, Date inputAssignedDate)
        {

            //Declare an assignment object
            Assignment assignment = new Assignment();

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by WorkID
                if(inputWorkID != null && !inputWorkID.trim().isEmpty())
                {
                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM Assignment WHERE workID = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to workID (? will be set to workID)
                    stmt.setString(1, inputWorkID);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        assignment = new Assignment
                                (
                                        rs.getString("assignmentID"),
                                        rs.getString("HCN"),
                                        rs.getString("workID"),
                                        rs.getDate("assignedDate")
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return assignment object
                    return assignment;
                }

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                        return null;
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM Assignment WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        assignment = new Assignment
                                (
                                        rs.getString("assignmentID"),
                                        rs.getString("HCN"),
                                        rs.getString("workID"),
                                        rs.getDate("assignedDate")
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return object
                    return assignment;

                }

            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }

            //Return no results if user input does not match any database entries
            return null;

        }

        //Method to create an assignment in the database
        public void createAssignment(String inputAssignmentID, String inputHCN, String inputWorkID, Date inputAssignedDate)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Query for creating a new entry into the database
                String query = "INSERT INTO Assignment VALUES ('?', '?', '?', '?', '?', '?')";
                PreparedStatement stmt = con.prepareStatement(query);
                rs.getString("assignmentID"),
                        rs.getString("HCN"),
                        rs.getString("workID"),
                        rs.getDate("assignedDate")

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

        //Method to modify an assignment in the database
        public void modifyAssignment(String inputAssignmentID, String inputHCN, String inputWorkID, Date inputAssignedDate)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if (nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "UPDATE Assignment SET assignmentID = ? AND HCN = ? AND workID = ? AND assignedDate = ? WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, inputAssignmentID);
                    stmt.setString(2, inputHCN);
                    stmt.setString(3, inputWorkID);
                    stmt.setDate(4, (java.sql.Date) inputAssignedDate);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Close resources
                    rs.close();
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Method to delete an assignment in the database
        public void deleteAssignment(String inputFullName)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "DELETE FROM Assignment WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    stmt.executeUpdate();

                    //Close resources
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

}