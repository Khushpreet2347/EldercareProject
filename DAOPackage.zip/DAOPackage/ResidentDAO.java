package DAOPackage;

import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Connector.SQLConnection;
import ClassPackage.Resident;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ResidentDAO
{

    //Method that returns a list of Resident objects to access data from
    public List<Resident> getAllResidents()
    {

        //Declare a list Resident objects
        List<Resident> residents = new ArrayList<>();

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Resident");

            //Populate Resident objects
            while (rs.next())
            {
                Resident resident = new Resident
                        (
                                rs.getString("HCN"),
                                rs.getString("fName"),
                                rs.getString("lName"),
                                rs.getString("dateOfBirth"),
                                rs.getString("email"),
                                rs.getString("phoneNo"),
                                rs.getBlob("profileImage"),
                                rs.getString("eContact_fName"),
                                rs.getString("eContact_phoneNo")
                        );

                residents.add(resident);
            }

            rs.close();
            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return residents;

    }

    //Method that returns one resident object to access data from (BY WORK ID)
    public Resident getOneResidentViaID(String inputHCN)
    {

        Resident resident = null;

        try
        {

            Connection con = SQLConnection.getConnection();

            if (inputHCN != null && !inputHCN.trim().isEmpty())
            {
                String query = "SELECT * FROM Resident WHERE HCN = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputHCN);

                ResultSet rs = stmt.executeQuery();

                while (rs.next())
                {
                    resident = new Resident
                            (
                                    rs.getString("HCN"),
                                    rs.getString("fName"),
                                    rs.getString("lName"),
                                    rs.getString("dateOfBirth"),
                                    rs.getString("email"),
                                    rs.getString("phoneNo"),
                                    rs.getBlob("profileImage"),
                                    rs.getString("eContact_fName"),
                                    rs.getString("eContact_phoneNo")
                            );
                }

                rs.close();
                stmt.close();
                con.close();

                return resident;
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return null;

    }

    //Method that returns one resident object to access data from (BY NAME)
    public Resident getOneResidentViaName(String inputFullName)
    {

        Resident resident = null;

        try
        {

            Connection con = SQLConnection.getConnection();

            if (inputFullName != null && !inputFullName.trim().isEmpty())
            {

                String[] nameSplit = inputFullName.trim().split(" ");

                if (nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                    return null;
                }

                String fName = nameSplit[0];
                String lName = nameSplit[1];

                String query = "SELECT * FROM Resident WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                ResultSet rs = stmt.executeQuery();

                while (rs.next())
                {
                    resident = new Resident
                            (
                                    rs.getString("HCN"),
                                    rs.getString("fName"),
                                    rs.getString("lName"),
                                    rs.getString("dateOfBirth"),
                                    rs.getString("email"),
                                    rs.getString("phoneNo"),
                                    rs.getBlob("profileImage"),
                                    rs.getString("eContact_fName"),
                                    rs.getString("eContact_phoneNo")
                            );
                }

                rs.close();
                stmt.close();
                con.close();

                return resident;

            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return null;

    }

    //Method to create a resident in the database
    public void createResident(String inputHCN, String inputFName, String inputLName, java.sql.Date inputDateOfBirth, String inputEmail, String inputPhoneNo, InputStream inputProfileImage, String inputEContactFName, String inputEContactPhoneNo)
    {

        try
        {

            Connection con = SQLConnection.getConnection();

            String query = "INSERT INTO Resident (HCN, fName, lName, dateOfBirth, email, phoneNo, profileImage, eContact_fName, eContact_phoneNo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, inputHCN);
            stmt.setString(2, inputFName);
            stmt.setString(3, inputLName);
            stmt.setDate(4, inputDateOfBirth);
            stmt.setString(5, inputEmail);
            stmt.setString(6, inputPhoneNo);
            stmt.setBinaryStream(7, inputProfileImage);
            stmt.setString(8, inputEContactFName);
            stmt.setString(9, inputEContactPhoneNo);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    //Method to modify a resident in the database
    public void modifyResident(String inputHCN, String inputFName, String inputLName, String inputDateOfBirth, String inputEmail, String inputPhoneNo, InputStream inputProfileImage, String inputEContactFName, String inputEContactPhoneNo)
    {

        try
        {

            Connection con = SQLConnection.getConnection();

            java.sql.Date dob = java.sql.Date.valueOf(inputDateOfBirth);

            String query = "UPDATE Resident SET HCN = ?, fName = ?, lName = ?, dateOfBirth = ?, email = ?, phoneNo = ?, profileImage = ?, eContact_fName = ?, eContact_phoneNo = ? WHERE HCN = ?";
            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, inputHCN);
            stmt.setString(2, inputFName);
            stmt.setString(3, inputLName);
            stmt.setDate(4, dob);
            stmt.setString(5, inputEmail);
            stmt.setString(6, inputPhoneNo);
            stmt.setBinaryStream(7, inputProfileImage);
            stmt.setString(8, inputEContactFName);
            stmt.setString(9, inputEContactPhoneNo);
            stmt.setString(10, inputHCN);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    //Method to delete a resident in the database
    public void deleteResident(String inputHCN)
    {

        try
        {

            Connection con = SQLConnection.getConnection();

            String query = "DELETE FROM Resident WHERE HCN = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputHCN);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

}