package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.Resident;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ResidentDAO
{

    //Method that returns a list of Resident objects to access data from
    public List<Resident> getResidents() {

        //Declare a list Resident objects
        List<Resident> residents = new ArrayList<>();

        //Connect to database
        try {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Resident");

            //Populate Resident objects
            while (rs.next()) {
                Resident resident = new Resident
                        (
                                rs.getString("HCN"),
                                rs.getString("fName"),
                                rs.getString("lName"),
                                rs.getString("dateOfBirth"),
                                rs.getString("email"),
                                rs.getString("phoneNo"),
                                rs.getString("profileImage"),
                                rs.getString("eContactFName"),
                                rs.getString("eContactPhoneNo")
                        );

                //Add objects to List
                residents.add(resident);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //Return a list of Resident objects
        return residents;

    }
/*
    //Method that returns one resident object to access data from
    public Resident getOneResident(String inputHCN, String inputFullName)
    {

        //Declare a Resident object
        Resident resident = new Resident();

        //Variables to save data to for the object
        String HCN; //PK
        String fName;
        String lName;
        String dateOfBirth;
        String email;
        String phoneNo;
        String profileImage; //image path
        String eContactFName;
        String eContactPhoneNo;

        //Connect to database
        try
        {

            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();

            if(inputHCN != null)
            {

            }

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }



    }
*/
//Method that returns one resident object to access data from
public Resident getOneResident(String inputHCN, String inputFName, String inputLName, String inputDateOfBirth, String inputEmail, String inputPhoneNo,
                               String inputProfileImage, String inputEContactFName, String inputEContactPhoneNo)
{

    //Declare a resident object
    Resident resident = new Resident();

    //Connect to database
    try
    {

        Connection con = SQLConnection.getConnection();

        //Search by WorkID
        if(inputWorkID != null && !inputWorkID.trim().isEmpty())
        {
            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM Resident WHERE workID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            //Set string to workID (? will be set to workID)
            stmt.setString(1, inputWorkID);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while (rs.next())
            {
                resident = new Resident
                        (
                                rs.getString("HCN"),
                                rs.getString("fName"),
                                rs.getString("lName"),
                                rs.getString("dateOfBirth"),
                                rs.getString("email"),
                                rs.getString("phoneNo"),
                                rs.getString("profileImage"),
                                rs.getString("eContactFName"),
                                rs.getString("eContactPhoneNo")
                        );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return resident object
            return resident;
        }

        //Search by full name
        if(inputFullName != null && !inputFullName.trim().isEmpty())
        {

            //Split the full name into a first and last name
            String[] nameSplit = inputFullName.trim().split(" ");

            //Check if user entered a full name
            if(nameSplit.length < 2)
            {
                JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                return null;
            }

            //Save split full name to separate variables
            String fName = nameSplit[0];
            String lName = nameSplit[1];

            //Use a prepared statement in order to use user input in the query
            String query = "SELECT * FROM Resident WHERE fName = ? AND lName = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            //Set string to names (changes ? in statement to names)
            stmt.setString(1, fName);
            stmt.setString(2, lName);

            //Execute query
            ResultSet rs = stmt.executeQuery();

            //Save attributes to object
            while (rs.next())
            {
                resident = new Resident
                        (
                                rs.getString("HCN"),
                                rs.getString("fName"),
                                rs.getString("lName"),
                                rs.getString("dateOfBirth"),
                                rs.getString("email"),
                                rs.getString("phoneNo"),
                                rs.getString("profileImage"),
                                rs.getString("eContactFName"),
                                rs.getString("eContactPhoneNo")
                        );
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

            //Return object
            return resident;

        }

    }
    catch (SQLException e)
    {
        e.printStackTrace();
    }

    //Return no results if user input does not match any database entries
    return null;

}
        //Method to create a resident in the database
        public void createResident(String inputHCN, String inputFName, String inputLName, String inputDateOfBirth, String inputEmail, String inputPhoneNo,
                                   String inputProfileImage, String inputEContactFName, String inputEContactPhoneNo)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Query for creating a new entry into the database
                String query = "INSERT INTO Resident VALUES ('?', '?', '?', '?', '?', '?')";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, "HCN");
                stmt.setString(2, "fName");
                stmt.setString(3, "lName");
                stmt.setString(4, "dateOfBirth");
                stmt.setString(5, "email");
                stmt.setString(6, "phoneNo");
                stmt.setString(7, "profileImage");
                stmt.setString(8, "eContactFName");
                stmt.setString(9, "eContactPhoneNo");



                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

        //Method to modify a resident in the database
        public void modifyResident(String inputHCN, String inputFName, String inputLName, String inputDateOfBirth, String inputEmail, String inputPhoneNo,
                                   String inputProfileImage, String inputEContactFName, String inputEContactPhoneNo)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if (nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "UPDATE Resident SET workID = ? AND fName = ? AND lName = ? AND email = ? AND phoneNo = ? AND passwordHash = ? WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, inputHCN);
                    stmt.setString(2, inputFName);
                    stmt.setString(3, inputLName);
                    stmt.setString(4, inputDateOfBirth);
                    stmt.setString(5, inputEmail);
                    stmt.setString(6, inputPhoneNo);
                    stmt.setString(7, inputProfileImage);
                    stmt.setString(8, inputEContactFName);
                    stmt.setString(9, inputEContactPhoneNo);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Close resources
                    rs.close();
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Method to delete a resident in the database
        public void deleteResident(String inputHCN, String inputFName, String inputLName, String inputDateOfBirth, String inputEmail, String inputPhoneNo,
                                  String inputProfileImage, String inputEContactFName, String inputEContactPhoneNo)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "DELETE FROM Resident WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    stmt.executeUpdate();

                    //Close resources
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

}

