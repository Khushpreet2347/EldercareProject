package DAOPackage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Connector.SQLConnection;
import MainPackage.PasswordUtil;
import ClassPackage.Manager;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ManagerDAO
{

    //Method that returns a list of Manager objects to access data from
    public List<Manager> getAllManagers()
    {

        //Declare a list of Manager objects
        List<Manager> managers = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Manager");

            //Populate Manager objects
            while(rs.next())
            {
                Manager manager = new Manager
                        (
                                rs.getString("workID"),
                                rs.getString("fName"),
                                rs.getString("lName"),
                                rs.getString("email"),
                                rs.getString("phoneNo"),
                                rs.getString("passwordHash")
                        );

                managers.add(manager);
            }

            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return managers;

    }

    public Manager getOneManagerViaID(String inputWorkID)
    {

        Manager manager = null;

        try
        {

            Connection con = SQLConnection.getConnection();

            if(inputWorkID != null && !inputWorkID.trim().isEmpty())
            {
                String query = "SELECT * FROM Manager WHERE workID = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, inputWorkID);

                ResultSet rs = stmt.executeQuery();

                while (rs.next())
                {
                    manager = new Manager
                            (
                                    rs.getString("workID"),
                                    rs.getString("fName"),
                                    rs.getString("lName"),
                                    rs.getString("email"),
                                    rs.getString("phoneNo"),
                                    rs.getString("passwordHash")
                            );
                }

                rs.close();
                stmt.close();
                con.close();

                return manager;
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return null;

    }

    public Manager getOneManagerViaName(String inputFullName)
    {

        Manager manager = null;

        try
        {

            Connection con = SQLConnection.getConnection();

            if(inputFullName != null && !inputFullName.trim().isEmpty())
            {

                String[] nameSplit = inputFullName.trim().split(" ");

                if(nameSplit.length < 2)
                {
                    JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                    return null;
                }

                String fName = nameSplit[0];
                String lName = nameSplit[1];

                String query = "SELECT * FROM Manager WHERE fName = ? AND lName = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, fName);
                stmt.setString(2, lName);

                ResultSet rs = stmt.executeQuery();

                while (rs.next())
                {
                    manager = new Manager
                            (
                                    rs.getString("workID"),
                                    rs.getString("fName"),
                                    rs.getString("lName"),
                                    rs.getString("email"),
                                    rs.getString("phoneNo"),
                                    rs.getString("passwordHash")
                            );
                }

                rs.close();
                stmt.close();
                con.close();

                return manager;

            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return null;

    }

    public void createManager(String inputWorkID, String inputFName, String inputLName, String inputEmail, String inputPhoneNo, String inputPasswordHash)
    {

        try
        {

            Connection con = SQLConnection.getConnection();

            String query = "INSERT INTO Manager (workID, fName, lName, email, phoneNo, passwordHash) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, inputWorkID);
            stmt.setString(2, inputFName);
            stmt.setString(3, inputLName);
            stmt.setString(4, inputEmail);
            stmt.setString(5, inputPhoneNo);

            String hashedPassword = PasswordUtil.hashPassword(inputPasswordHash);
            stmt.setString(6, hashedPassword);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

    public void modifyManager(String inputWorkID, String inputFName, String inputLName, String inputEmail, String inputPhoneNo, String inputPasswordHash)
    {

        try
        {

            Connection con = SQLConnection.getConnection();

            String query = "UPDATE Manager SET fName = ?, lName = ?, email = ?, phoneNo = ?, passwordHash = ? WHERE workID = ?";
            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, inputFName);
            stmt.setString(2, inputLName);
            stmt.setString(3, inputEmail);
            stmt.setString(4, inputPhoneNo);

            String hashedPassword = PasswordUtil.hashPassword(inputPasswordHash);
            stmt.setString(5, hashedPassword);

            stmt.setString(6, inputWorkID);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void deleteManager(String inputWorkID)
    {

        try
        {

            Connection con = SQLConnection.getConnection();

            String query = "DELETE FROM Manager WHERE workID = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, inputWorkID);

            stmt.executeUpdate();

            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }

}