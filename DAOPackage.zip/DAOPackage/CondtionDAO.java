package DAOPackage;

import java.sql.*;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.Condition;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class CondtionDAO
{

    //Method that returns a list of Condition objects to access data from
    public List<Condition> getConditions()
    {

        //Declare a list of Conditions objects
        List<Condition> conditions = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM ConditionRecord");

            //Populate Condition objects
            while(rs.next())
            {
                Condition condition = new Condition
                    (
                        rs.getInt("recordID"),
                        rs.getInt("mood"),
                        rs.getInt("painLevel"),
                        rs.getInt("sleepQuality")
                    );

                //Add objects to List
                conditions.add(condition);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Condition objects
        return conditions;

    }
}

        //Method that returns one condition object to access data from
        public Condition getOneCondition(int inputRecordID, int inputMood, int inputPainLevel, int inputSleepQuality)
        {

            //Declare a Condition object
            Condition condition = new Condition();

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by WorkID
                if(inputWorkID != null && !inputWorkID.trim().isEmpty())
                {
                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM ConditionRecord WHERE workID = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to workID (? will be set to workID)
                    stmt.setString(1, inputWorkID);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        condition = new Condition
                                (
                                        rs.getInt("recordID"),
                                        rs.getInt("mood"),
                                        rs.getInt("painLevel"),
                                        rs.getInt("sleepQuality"),
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return condition object
                    return condition;
                }

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                        return null;
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM ConditionRecord WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        condition = new Condition
                                (
                                        rs.getInt("recordID"),
                                        rs.getInt("mood"),
                                        rs.getInt("painLevel"),
                                        rs.getInt("sleepQuality"),
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return object
                    return condition;

                }

            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }

            //Return no results if user input does not match any database entries
            return null;

        }

        //Method to create a condition in the database
        public void createCondition(int inputRecordID, int inputMood, int inputPainLevel, int inputSleepQuality)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Query for creating a new entry into the database
                String query = "INSERT INTO ConditionRecord VALUES ('?', '?', '?', '?', '?', '?')";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setInt(1, "recordID");
                stmt.setInt(2, "mood");
                stmt.setInt(3, "painLevel");
                stmt.setInt(4, "sleepQuality");

                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

        //Method to modify a condition in the database
        public void modifyCondition(int inputRecordID, int inputMood, int inputPainLevel, int inputSleepQuality)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if (nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "UPDATE ConditionRecord SET recordID = ? AND mood = ? AND painLevel = ? AND sleepQuality = ? WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setInt(1, inputRecordID);
                    stmt.setInt(2, inputMood);
                    stmt.setInt(3, inputPainLevel);
                    stmt.setInt(4, inputSleepQuality);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Close resources
                    rs.close();
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Method to delete a condition in the database
        public void deleteCondition(int recordID, int mood, int painLevel, int sleepQuality)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "DELETE FROM ConditionRecord WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    stmt.executeUpdate();

                    //Close resources
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

}
