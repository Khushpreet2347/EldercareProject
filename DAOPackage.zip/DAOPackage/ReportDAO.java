package DAOPackage;

import java.sql.*;
import java.sql.Date;
import java.util.*;

import ClassPackage.Manager;
import Connector.SQLConnection;
import ClassPackage.Report;

import javax.swing.*;

//This class creates objects from the database, acts as a bridge between the database and GUIs
public class ReportDAO
{

    //Method that returns a list of report objects to access data from
    public List<Report> getReports()
    {

        //Declare a list of Report objects
        List<Report> reports = new ArrayList<>();

        //Connect to database
        try
        {
            Connection con = SQLConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Report");

            //Populate Report objects
            while(rs.next())
            {
                Report report = new Report
                    (
                    rs.getInt("reportID"),
                    rs.getString("type"),
                    rs.getDate("generatedAt"),
                    rs.getString("content")
                    );

                //Add objects to List
                reports.add(report);
            }

            //Close resources
            rs.close();
            stmt.close();
            con.close();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        //Return list of Report objects
        return reports;

    }

}

        //Method that returns one report object to access data from
        public Report getOneReport(int InputReportID, String InputType, Date InputGeneratedAt, String inputContent)

            //Declare a report object
            Report report = new Report();

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by WorkID
                if(inputWorkID != null && !inputWorkID.trim().isEmpty())
                {
                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM Report WHERE workID = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to workID (? will be set to workID)
                    stmt.setString(1, inputWorkID);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        report = new Report
                                (
                                        rs.getInt("reportID"),
                                        rs.getString("type"),
                                        rs.getDate("generatedAt"),
                                        rs.getString("content")
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return report object
                    return report;
                }

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter both a first and a last name");
                        return null;
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "SELECT * FROM Report WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Save attributes to object
                    while (rs.next())
                    {
                        report = new Report
                                (
                                        rs.getInt("reportID"),
                                        rs.getString("type"),
                                        rs.getDate("generatedAt"),
                                        rs.getString("content")
                                );
                    }

                    //Close resources
                    rs.close();
                    stmt.close();
                    con.close();

                    //Return object
                    return report;

                }

            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }

            //Return no results if user input does not match any database entries
            return null;

        }

        //Method to create a report in the database
        public void createReport(int InputReportID, String InputType, Date InputGeneratedAt, String inputContent)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Query for creating a new entry into the database
                String query = "INSERT INTO Report VALUES ('?', '?', '?', '?', '?', '?')";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setInt(1, "reportID");
                stmt.setString(2, "type");
                stmt.setDate(3, "generatedAt");
                stmt.setString(4, "content");


                //Execute query
                stmt.executeUpdate();

                //Close resources
                stmt.close();
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

        //Method to modify a report in the database
        public void modifyReport(int InputReportID, String InputType, Date InputGeneratedAt, String inputContent)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if (nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "UPDATE Report SET workID = ? AND fName = ? AND lName = ? AND email = ? AND phoneNo = ? AND passwordHash = ? WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    //Set string to names (changes ? in statement to names)
                    stmt.setInt(1, inputReportID);
                    stmt.setString(2, inputType);
                    stmt.setDate(3, inputGeneratedAt);
                    stmt.setString(4, inputContent);
                    //Execute query
                    ResultSet rs = stmt.executeQuery();

                    //Close resources
                    rs.close();
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }

        //Method to delete a report in the database
        public void deleteReport(int InputReportID, String InputType, Date InputGeneratedAt, String inputContent)
        {

            //Connect to database
            try
            {

                Connection con = SQLConnection.getConnection();

                //Search by full name
                if(inputFullName != null && !inputFullName.trim().isEmpty())
                {

                    //Split the full name into a first and last name
                    String[] nameSplit = inputFullName.trim().split(" ");

                    //Check if user entered a full name
                    if(nameSplit.length < 2)
                    {
                        JOptionPane.showMessageDialog(null, "Please enter a first and last name");
                    }

                    //Save split full name to separate variables
                    String fName = nameSplit[0];
                    String lName = nameSplit[1];

                    //Use a prepared statement in order to use user input in the query
                    String query = "DELETE FROM Report WHERE fName = ? AND lName = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, fName);
                    stmt.setString(2, lName);

                    //Execute query
                    stmt.executeUpdate();

                    //Close resources
                    stmt.close();

                }

                //Close connection
                con.close();

            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

}