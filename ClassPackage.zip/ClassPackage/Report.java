package ClassPackage;

import java.util.Date;

public class Report
{

	//Variables
	private int reportID; //PK
	private String type; // User Medication Summary or Health Irregularities Summary
	private String content;

	//Constructors
	public Report()
	{
		reportID = 0;
		type = "";
		content = "";
	}

	public Report(int reportID, String type, String content)
	{
		this.reportID = reportID;
		this.type = type;
		this.content = content;
	}

	//Getters & Setters
	public int getReportID() {
		return reportID;
	}

	public void setReportID(int reportID) {
		this.reportID = reportID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	//To String method
	@Override
	public String toString()
	{
		return "Report{" +
				"reportID=" + reportID +
				", type='" + type + '\'' +
				", content='" + content + '\'' +
				'}';
	}

}