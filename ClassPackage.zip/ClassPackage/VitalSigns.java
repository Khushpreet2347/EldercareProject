package ClassPackage;

public class VitalSigns
{

	//Variables
	private int recordID; // PK, FK from ClassPackage.HealthRecord
	private int systolic;
	private int diastolic;
	private int bloodSugar;
	private double temperature;
	private int heartRate;

	//Constructors
	public VitalSigns()
	{
		recordID = 0;
		systolic = 0;
		diastolic = 0;
		bloodSugar = 0;
		temperature = 0.0;
		heartRate = 0;
	}

	public VitalSigns(int recordID, int systolic, int diastolic, int bloodSugar, double temperature, int heartRate)
	{
		this.recordID = recordID;
		this.systolic = systolic;
		this.diastolic = diastolic;
		this.bloodSugar = bloodSugar;
		this.temperature = temperature;
		this.heartRate = heartRate;
	}

	//Getters & Setters
	public int getRecordID() {return recordID;
	}

	public void setRecordID(int recordID) {this.recordID = recordID;
	}

	public int getSystolic() {return systolic;
	}

	public void setSystolic(int systolic) {this.systolic = systolic;
	}

	public int getDiastolic() {return diastolic;
	}

	public void setDiastolic(int diastolic) {this.diastolic = diastolic;
	}

	public int getBloodSugar() {return bloodSugar;
	}

	public void setBloodSugar(int bloodSugar) {this.bloodSugar = bloodSugar;
	}

	public double getTemperature() {return temperature;
	}

	public void setTemperature(double temperature) {this.temperature = temperature;
	}

	public int getHeartRate() {return heartRate;
	}

	public void setHeartRate(int heartRate) {this.heartRate = heartRate;
	}

	//To String Method
	@Override
	public String toString()
	{
		return "VitalSigns{" +
				"recordID=" + recordID +
				", systolic=" + systolic +
				", diastolic=" + diastolic +
				", bloodSugar=" + bloodSugar +
				", temperature=" + temperature +
				", heartRate=" + heartRate +
				'}';
	}

}