package ClassPackage;

import java.sql.Date;
import java.sql.Time;

public class HealthRecord
{

	//Variables
	private int recordID; // PK
	private String HCN;   // FK from Residents
	private Date entryDate;
	private Time entryTime;
	private String note;

	//Constructor
	public HealthRecord(int recordID, String HCN, Date entryDate, Time entryTime, String note)
	{
		this.recordID = recordID;
		this.HCN = HCN;
		this.entryDate = entryDate;
		this.entryTime = entryTime;
		this.note = note;
	}

	//Constructor - INSERT
	public HealthRecord(String HCN, Date entryDate, Time entryTime, String note)
	{
		this.HCN = HCN;
		this.entryDate = entryDate;
		this.entryTime = entryTime;
		this.note = note;
	}

	//Getters and Setters
	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public String getHCN() {
		return HCN;
	}

	public void setHCN(String HCN) {
		this.HCN = HCN;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public Time getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(Time entryTime) {
		this.entryTime = entryTime;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	//To String
	@Override
	public String toString()
	{
		return "HealthRecord{" +
				"recordID=" + recordID +
				", HCN='" + HCN + '\'' +
				", entryDate=" + entryDate +
				", entryTime=" + entryTime +
				", note='" + note + '\'' +
				'}';
	}
}